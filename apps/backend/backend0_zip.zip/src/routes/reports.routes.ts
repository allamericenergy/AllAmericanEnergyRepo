import { Router } from "express";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { Prisma } from "@prisma/client";
import { authenticate } from "../middleware/authenticate.js";
import { authorize } from "../middleware/authorize.js";
import { scopedOrgId } from "../middleware/tenant.js";
import { prisma } from "../db/prisma.js";
import { env } from "../config/env.js";
import { demoAuditLogs, demoDeals } from "../demo/demoData.js";
import { createCompanySharePointFolders, ensureContractsFolder, getSharePointFileContent, listCompanySharePointDocuments, uploadSharePointFile } from "../services/sharepointFolders.js";
import { emailService } from "../services/emailService.js";
import { contractUploadFileName } from "../services/contractFileName.js";

export const reportsRoutes = Router();

reportsRoutes.use(authenticate);

reportsRoutes.get("/pipeline", authorize("report:read"), async (req, res, next) => {
  try {
    if (env.DEMO_MODE) {
      const stages = new Map<string, { stage: string; _count: { id: number }; _sum: { amount: number } }>();
      for (const deal of demoDeals) {
        const current = stages.get(deal.stage) ?? { stage: deal.stage, _count: { id: 0 }, _sum: { amount: 0 } };
        current._count.id += 1;
        current._sum.amount += deal.amount;
        stages.set(deal.stage, current);
      }
      return res.json({ data: [...stages.values()] });
    }

    const orgId = scopedOrgId(req);
    const deals = await prisma.deal.groupBy({
      by: ["stage"],
      where: { orgId: orgId ?? undefined },
      _count: { id: true },
      _sum: { amount: true }
    });

    return res.json({ data: deals });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/activity", authorize("report:read"), async (req, res, next) => {
  try {
    if (env.DEMO_MODE) {
      return res.json({ data: demoAuditLogs });
    }

    const orgId = scopedOrgId(req);
    const data = await prisma.auditLog.findMany({
      where: { orgId: orgId ?? undefined },
      orderBy: { createdAt: "desc" },
      take: 50
    });

    return res.json({ data });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/organizations", authorize("org:administer"), async (_req, res, next) => {
  try {
    const organizations = await prisma.organization.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        _count: {
          select: {
            users: true,
            companies: true,
            contacts: true,
            deals: true,
            tasks: true
          }
        }
      }
    });

    return res.json({
      total: organizations.length,
      data: organizations.map((entry: {
        _count: { users: number; companies: number; contacts: number; deals: number; tasks: number };
        [key: string]: unknown;
      }) => {
        const { _count, ...organization } = entry;
        return {
          ...organization,
          usersCount: _count.users,
          companiesCount: _count.companies,
          contactsCount: _count.contacts,
          dealsCount: _count.deals,
          tasksCount: _count.tasks
        };
      })
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/team-members", async (req, res, next) => {
  try {
    const orgId = req.user?.role === "superadmin" ? undefined : req.user?.orgId ?? undefined;
    const taggableRoles = req.user?.role === "admin"
      ? ["superadmin", "admin", "member"]
      : ["admin", "member", "user"];
    const users = await prisma.user.findMany({
      where: {
        ...(orgId ? { orgId } : {}),
        role: { in: taggableRoles },
        status: "active"
      },
      orderBy: [{ firstName: "asc" }, { lastName: "asc" }],
      select: { id: true, firstName: true, lastName: true, email: true, role: true, designation: true, orgId: true }
    });
    return res.json({ data: users });
  } catch (error) {
    return next(error);
  }
});

async function attachActivityConversation<T extends { id: string }>(activities: T[]) {
  const activityIds = activities.map((activity) => activity.id);
  if (!activityIds.length) return activities.map((activity) => ({ ...activity, createdBy: null, replies: [] }));
  const [creatorEvents, replies] = await Promise.all([
    prisma.auditLog.findMany({
      where: { objectType: "companyActivity", objectId: { in: activityIds }, action: "tagged" },
      orderBy: { createdAt: "asc" },
      include: { user: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    }),
    prisma.note.findMany({
      where: { relatedType: "companyActivityReply", relatedId: { in: activityIds } },
      orderBy: { createdAt: "asc" },
      include: { user: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    })
  ]);
  const creators = new Map<string, (typeof creatorEvents)[number]["user"]>();
  for (const event of creatorEvents) {
    if (event.objectId && !creators.has(event.objectId)) creators.set(event.objectId, event.user);
  }
  const repliesByActivity = new Map<string, typeof replies>();
  for (const reply of replies) {
    const current = repliesByActivity.get(reply.relatedId) ?? [];
    current.push(reply);
    repliesByActivity.set(reply.relatedId, current);
  }
  return activities.map((activity) => ({
    ...activity,
    createdBy: creators.get(activity.id) ?? null,
    replies: repliesByActivity.get(activity.id) ?? []
  }));
}

reportsRoutes.get("/my-company-activities", async (req, res, next) => {
  try {
    const activities = await prisma.task.findMany({
      where: { assigneeId: req.user!.id, relatedType: "tblCompanyActivity" },
      orderBy: { createdAt: "desc" },
      include: { assignee: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    });
    const companyIds = Array.from(new Set(activities.map((activity) => Number(activity.relatedId)).filter((id) => Number.isInteger(id) && id > 0)));
    const companies = companyIds.length ? await prisma.$queryRaw<Array<{ id: number; companyName: string | null }>>(Prisma.sql`
      SELECT [id], [Company Name] AS [companyName]
      FROM dbo.tblCompany
      WHERE [id] IN (${Prisma.join(companyIds)})
    `) : [];
    const companyNames = new Map(companies.map((company) => [String(company.id), company.companyName]));
    const data = (await attachActivityConversation(activities))
      .filter((activity) => activity.createdBy?.id !== req.user!.id)
      .map((activity) => ({
        ...activity,
        companyId: activity.relatedId,
        companyName: companyNames.get(String(activity.relatedId)) ?? `Company ${activity.relatedId}`
      }));
    const todos = data.filter((activity) => activity.status !== "note");
    const notes = data.filter((activity) => activity.status === "note");
    return res.json({ data, counts: { todos: todos.length, notes: notes.length, total: data.length } });
  } catch (error) {
    return next(error);
  }
});

function notificationCompanyId(actionUrl: string | null) {
  if (!actionUrl) return null;
  const queryMatch = actionUrl.match(/[?&]companyId=(\d+)/);
  if (queryMatch?.[1]) return queryMatch[1];
  const companyPathMatch = actionUrl.match(/\/companies\/(\d+)\/activities/);
  return companyPathMatch?.[1] ?? null;
}

reportsRoutes.get("/activity-unread-counts", async (req, res, next) => {
  try {
    const notifications = await prisma.notification.findMany({
      where: {
        userId: req.user!.id,
        type: { in: ["company_activity", "company_activity_reply"] },
        readAt: null,
        archivedAt: null,
        deletedAt: null
      },
      select: { actionUrl: true }
    });
    const byCompany: Record<string, number> = {};
    for (const notification of notifications) {
      const companyId = notificationCompanyId(notification.actionUrl);
      if (companyId) byCompany[companyId] = (byCompany[companyId] ?? 0) + 1;
    }
    return res.json({ total: notifications.length, byCompany });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/activity-notifications/read", async (req, res, next) => {
  try {
    const input = z.object({ companyId: z.coerce.number().int().positive().optional() }).parse(req.body ?? {});
    const baseWhere = {
      userId: req.user!.id,
      type: { in: ["company_activity", "company_activity_reply"] },
      readAt: null,
      archivedAt: null,
      deletedAt: null
    };
    const where = input.companyId
      ? {
          ...baseWhere,
          OR: [
            { actionUrl: { contains: `companyId=${input.companyId}` } },
            { actionUrl: { contains: `/companies/${input.companyId}/activities` } }
          ]
        }
      : baseWhere;
    const result = await prisma.notification.updateMany({ where, data: { readAt: new Date() } });
    return res.json({ updated: result.count });
  } catch (error) {
    return next(error);
  }
});

interface LegacyColumnMetadata {
  name: string;
  dataType: string;
  nullable: boolean;
  identity: boolean;
  computed: boolean;
  hasDefault: boolean;
  primaryKey: boolean;
  editable: boolean;
}

function sqlIdentifier(name: string) {
  const bracket = String.fromCharCode(93);
  return Prisma.raw("[" + name.replaceAll(bracket, bracket + bracket) + "]");
}

async function legacyTableColumns(tableName: string): Promise<LegacyColumnMetadata[]> {
  const qualifiedTableName = `dbo.${tableName}`;
  const columns = await prisma.$queryRaw<Array<{
    name: string;
    dataType: string;
    nullable: boolean | number;
    identity: boolean | number;
    computed: boolean | number;
    hasDefault: boolean | number;
    primaryKey: boolean | number;
  }>>`
    SELECT
      c.[COLUMN_NAME] AS [name],
      c.[DATA_TYPE] AS [dataType],
      CAST(CASE WHEN c.[IS_NULLABLE] = 'YES' THEN 1 ELSE 0 END AS bit) AS [nullable],
      CAST(COLUMNPROPERTY(OBJECT_ID(${qualifiedTableName}), c.[COLUMN_NAME], 'IsIdentity') AS bit) AS [identity],
      CAST(COLUMNPROPERTY(OBJECT_ID(${qualifiedTableName}), c.[COLUMN_NAME], 'IsComputed') AS bit) AS [computed],
      CAST(CASE WHEN c.[COLUMN_DEFAULT] IS NOT NULL THEN 1 ELSE 0 END AS bit) AS [hasDefault],
      CAST(CASE WHEN EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
        INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE ku
          ON tc.[CONSTRAINT_NAME] = ku.[CONSTRAINT_NAME]
          AND tc.[TABLE_SCHEMA] = ku.[TABLE_SCHEMA]
        WHERE tc.[TABLE_SCHEMA] = 'dbo'
          AND tc.[TABLE_NAME] = ${tableName}
          AND tc.[CONSTRAINT_TYPE] = 'PRIMARY KEY'
          AND ku.[COLUMN_NAME] = c.[COLUMN_NAME]
      ) THEN 1 ELSE 0 END AS bit) AS [primaryKey]
    FROM INFORMATION_SCHEMA.COLUMNS c
    WHERE c.[TABLE_SCHEMA] = 'dbo' AND c.[TABLE_NAME] = ${tableName}
    ORDER BY c.[ORDINAL_POSITION]
  `;

  if (!columns.length) {
    throw Object.assign(new Error(`dbo.${tableName} was not found`), { statusCode: 404 });
  }

  return columns.map((column) => ({
    ...column,
    nullable: Boolean(column.nullable),
    identity: Boolean(column.identity),
    computed: Boolean(column.computed),
    hasDefault: Boolean(column.hasDefault),
    primaryKey: Boolean(column.primaryKey),
    editable: !column.identity && !column.computed && column.dataType !== "timestamp" && !/^(createdAt|updatedAt)$/i.test(column.name)
  }));
}

function legacyValue(column: LegacyColumnMetadata, value: unknown) {
  if (value === "" || value === undefined) return column.nullable ? null : undefined;
  if (value === null) return column.nullable ? null : undefined;
  if (["tinyint", "smallint", "int", "bigint", "decimal", "numeric", "float", "real", "money", "smallmoney"].includes(column.dataType)) {
    const number = Number(value);
    if (!Number.isFinite(number)) throw Object.assign(new Error(`${column.name} must be a number`), { statusCode: 400 });
    return number;
  }
  if (column.dataType === "bit") {
    if (typeof value === "boolean") return value;
    if (value === "true" || value === 1 || value === "1") return true;
    if (value === "false" || value === 0 || value === "0") return false;
    throw Object.assign(new Error(`${column.name} must be true or false`), { statusCode: 400 });
  }
  if (["date", "datetime", "datetime2", "smalldatetime", "datetimeoffset"].includes(column.dataType)) {
    const date = new Date(String(value));
    if (Number.isNaN(date.getTime())) throw Object.assign(new Error(`${column.name} must be a valid date`), { statusCode: 400 });
    return date;
  }
  return String(value);
}

function writableLegacyValues(
  columns: LegacyColumnMetadata[],
  body: unknown,
  creating: boolean,
  singularName: string,
  requiredOnCreate: string[] = []
) {
  const input = z.record(z.unknown()).parse(body);
  const values = columns
    .filter((column) => column.editable && Object.prototype.hasOwnProperty.call(input, column.name))
    .map((column) => ({ column, value: legacyValue(column, input[column.name]) }))
    .filter((entry) => entry.value !== undefined);

  if (creating) {
    const requiredNames = new Set(requiredOnCreate.map((name) => name.toLowerCase()));
    const missing = columns.find((column) =>
      column.editable
      && ((!column.nullable && !column.hasDefault) || requiredNames.has(column.name.toLowerCase()))
      && !values.some((entry) => entry.column.name === column.name && entry.value !== null)
    );
    if (missing) throw Object.assign(new Error(`${missing.name} is required`), { statusCode: 400 });
  }
  if (!values.length) throw Object.assign(new Error(`No ${singularName.toLowerCase()} values were supplied`), { statusCode: 400 });
  return values;
}

function registerLegacyOrganizationRoutes(
  path: string,
  tableName: string,
  singularName: string,
  checkDuplicateOnCreate = false,
  requiredOnCreate: string[] = []
) {
  const table = Prisma.sql`${sqlIdentifier("dbo")}.${sqlIdentifier(tableName)}`;

  reportsRoutes.get(path, authorize("org:administer"), async (req, res, next) => {
    try {
      const take = Math.min(Math.max(Number(req.query.take ?? 500) || 500, 1), 500);
      const columns = await legacyTableColumns(tableName);
      const primaryKey = columns.find((column) => column.primaryKey) ?? columns.find((column) => column.name.toLowerCase() === "id");
      const [countRows, rows] = await Promise.all([
        prisma.$queryRaw<Array<{ total: bigint | number }>>(Prisma.sql`SELECT COUNT(*) AS total FROM ${table}`),
        prisma.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
          SELECT TOP (${take}) * FROM ${table}
          ${primaryKey ? Prisma.sql`ORDER BY ${sqlIdentifier(primaryKey.name)} DESC` : Prisma.empty}
        `)
      ]);
      return res.json({
        total: Number(countRows[0]?.total ?? 0),
        primaryKey: primaryKey?.name ?? null,
        columns,
        data: rows
      });
    } catch (error) {
      return next(error);
    }
  });

  reportsRoutes.post(path, authorize("org:administer"), async (req, res, next) => {
    try {
      const columns = await legacyTableColumns(tableName);
      const missingSchemaColumn = requiredOnCreate.find((requiredName) =>
        !columns.some((column) => column.name.toLowerCase() === requiredName.toLowerCase())
      );
      if (missingSchemaColumn) {
        throw Object.assign(new Error(`${tableName}.${missingSchemaColumn} is not configured`), { statusCode: 500 });
      }
      const values = writableLegacyValues(columns, req.body, true, singularName, requiredOnCreate);
      if (checkDuplicateOnCreate) {
        const duplicateConditions = values.map(({ column, value }) => value === null
          ? Prisma.sql`${sqlIdentifier(column.name)} IS NULL`
          : Prisma.sql`${sqlIdentifier(column.name)} = ${value}`);
        const existing = await prisma.$queryRaw<Array<{ exists: number }>>(Prisma.sql`
          SELECT TOP (1) 1 AS [exists]
          FROM ${table}
          WHERE ${Prisma.join(duplicateConditions, " AND ")}
        `);
        if (existing.length) {
          return res.status(409).json({ error: `${singularName} already exists` });
        }
      }
      const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
        INSERT INTO ${table} (${Prisma.join(values.map(({ column }) => sqlIdentifier(column.name)))})
        OUTPUT INSERTED.*
        VALUES (${Prisma.join(values.map(({ value }) => value))})
      `);
      return res.status(201).json({ data: rows[0] });
    } catch (error) {
      return next(error);
    }
  });

  reportsRoutes.patch(`${path}/:id`, authorize("org:administer"), async (req, res, next) => {
    try {
      const columns = await legacyTableColumns(tableName);
      const primaryKey = columns.find((column) => column.primaryKey) ?? columns.find((column) => column.name.toLowerCase() === "id");
      if (!primaryKey) return res.status(409).json({ error: `${tableName} needs a primary key to edit records` });
      const id = legacyValue(primaryKey, req.params.id);
      const values = writableLegacyValues(columns, req.body, false, singularName);
      const assignments = values.map(({ column, value }) => Prisma.sql`${sqlIdentifier(column.name)} = ${value}`);
      const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
        UPDATE ${table}
        SET ${Prisma.join(assignments)}
        OUTPUT INSERTED.*
        WHERE ${sqlIdentifier(primaryKey.name)} = ${id}
      `);
      if (!rows[0]) return res.status(404).json({ error: `${singularName} not found` });
      return res.json({ data: rows[0] });
    } catch (error) {
      return next(error);
    }
  });

  reportsRoutes.delete(`${path}/:id`, authorize("org:administer"), async (req, res, next) => {
    try {
      const columns = await legacyTableColumns(tableName);
      const primaryKey = columns.find((column) => column.primaryKey) ?? columns.find((column) => column.name.toLowerCase() === "id");
      if (!primaryKey) return res.status(409).json({ error: `${tableName} needs a primary key to delete records` });
      const id = legacyValue(primaryKey, req.params.id);
      const deleted = await prisma.$executeRaw(Prisma.sql`
        DELETE FROM ${table} WHERE ${sqlIdentifier(primaryKey.name)} = ${id}
      `);
      if (!deleted) return res.status(404).json({ error: `${singularName} not found` });
      return res.status(204).send();
    } catch (error) {
      return next(error);
    }
  });
}

registerLegacyOrganizationRoutes("/rates", "tbl_Rate", "Rate", false, ["UtilityId"]);
registerLegacyOrganizationRoutes("/brokers", "tbl_Broker", "Broker");
registerLegacyOrganizationRoutes("/suppliers", "tbl_Supplier", "Supplier");
registerLegacyOrganizationRoutes("/onsite-generations", "tbl_OnSiteGeneration", "OnSiteGeneration", true);
registerLegacyOrganizationRoutes("/pass-throughs", "tbl_PassThrough", "PassThrough", true);
registerLegacyOrganizationRoutes("/products", "tbl_Product", "Product", true);
registerLegacyOrganizationRoutes("/utilities", "tbl_Utility", "Utility", true);
registerLegacyOrganizationRoutes("/swings", "tbl_Swing", "Swing", true);
registerLegacyOrganizationRoutes("/types", "tbl_Type", "Type", true);

reportsRoutes.post("/rates/bulk", authorize("org:administer"), async (req, res, next) => {
  try {
    const input = z.object({
      utilityId: z.coerce.number().int().positive(),
      rows: z.array(z.record(z.unknown())).min(1).max(1000)
    }).parse(req.body);
    const columns = await legacyTableColumns("tbl_Rate");
    const editableColumns = columns.filter((column) => column.editable);
    const utilityColumn = editableColumns.find((column) => column.name.toLowerCase() === "utilityid");
    if (!utilityColumn) throw Object.assign(new Error("tbl_Rate.UtilityId is not configured"), { statusCode: 500 });
    const utilityRows = await prisma.$queryRaw<Array<{ id: number }>>`
      SELECT TOP (1) [id] FROM dbo.tbl_Utility WHERE [id] = ${input.utilityId}
    `;
    if (!utilityRows[0]) return res.status(400).json({ error: "Selected utility was not found" });
    const normalizeHeader = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");
    const columnByHeader = new Map(editableColumns.map((column) => [normalizeHeader(column.name), column.name]));
    const mappedRows = input.rows.map((row, index) => {
      const mapped: Record<string, unknown> = {};
      for (const [header, value] of Object.entries(row)) {
        const columnName = columnByHeader.get(normalizeHeader(header));
        if (columnName) mapped[columnName] = value;
      }
      mapped[utilityColumn.name] = input.utilityId;
      try {
        return writableLegacyValues(columns, mapped, true, `Rate row ${index + 2}`, ["UtilityId"]);
      } catch (error) {
        const message = error instanceof Error ? error.message : "Invalid rate data";
        throw Object.assign(new Error(`Row ${index + 2}: ${message}`), { statusCode: 400 });
      }
    });
    const table = Prisma.sql`${sqlIdentifier("dbo")}.${sqlIdentifier("tbl_Rate")}`;
    const imported = await prisma.$transaction(async (transaction) => {
      const records: Array<Record<string, unknown>> = [];
      for (const values of mappedRows) {
        const rows = await transaction.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
          INSERT INTO ${table} (${Prisma.join(values.map(({ column }) => sqlIdentifier(column.name)))})
          OUTPUT INSERTED.*
          VALUES (${Prisma.join(values.map(({ value }) => value))})
        `);
        if (rows[0]) records.push(rows[0]);
      }
      return records;
    });
    return res.status(201).json({ imported: imported.length, data: imported });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/organization-notes", authorize("org:administer"), async (req, res, next) => {
  try {
    const take = Math.min(Math.max(Number(req.query.take ?? 500) || 500, 1), 500);
    const [total, notes] = await Promise.all([prisma.note.count(), prisma.note.findMany({
      orderBy: { updatedAt: "desc" },
      take,
      select: {
        id: true,
        content: true,
        relatedType: true,
        relatedId: true,
        companyId: true,
        createdAt: true,
        updatedAt: true,
        user: { select: { id: true, firstName: true, lastName: true, email: true } },
        org: { select: { id: true, name: true } }
      }
    })]);

    const companyIds = Array.from(new Set(notes
      .map((note) => note.companyId ?? (note.relatedType === "company" ? Number(note.relatedId) : 0))
      .filter((id) => Number.isInteger(id) && id > 0)));
    const companies = companyIds.length ? await prisma.$queryRaw<Array<{ id: number; name: string | null }>>(Prisma.sql`
      SELECT [id], [Company Name] AS [name]
      FROM dbo.tblCompany
      WHERE [id] IN (${Prisma.join(companyIds)})
    `) : [];
    const companyNames = new Map(companies.map((company) => [String(company.id), company.name ?? `Company ${company.id}`]));

    const memberIds = Array.from(new Set(notes.filter((note) => note.relatedType === "member").map((note) => note.relatedId)));
    const members = memberIds.length ? await prisma.user.findMany({
      where: { id: { in: memberIds } },
      select: { id: true, firstName: true, lastName: true, email: true }
    }) : [];
    const memberNames = new Map(members.map((member) => [member.id, [member.firstName, member.lastName].filter(Boolean).join(" ") || member.email]));

    return res.json({
      total,
      data: notes.map((note) => {
        const relatedName = note.relatedType === "company"
          ? companyNames.get(String(note.companyId ?? note.relatedId))
          : note.relatedType === "member"
            ? memberNames.get(note.relatedId)
            : undefined;
        return {
          id: note.id,
          content: sanitizeCompanyNoteContent(note.content),
          relatedType: note.relatedType,
          relatedId: note.relatedId,
          relatedName: relatedName ?? note.relatedId,
          companyId: note.companyId,
          authorId: note.user.id,
          authorName: [note.user.firstName, note.user.lastName].filter(Boolean).join(" ") || note.user.email,
          authorEmail: note.user.email,
          organizationId: note.org.id,
          organizationName: note.org.name,
          createdAt: note.createdAt,
          updatedAt: note.updatedAt
        };
      })
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/tbl-companies", authorize("report:read"), async (req, res, next) => {
  try {
    const take = Math.min(Number(req.query.take ?? 100), 500);
    const countRows = await rawUnsafeRows<{ total: bigint | number }>("SELECT COUNT(*) AS total FROM dbo.tblCompany");
    const rows = await rawUnsafeRows<Record<string, unknown>>(`
      SELECT TOP (${take})
        [id] AS id,
        [organizationId] AS organizationId,
        [Customer ID] AS customerId,
        [Company Name] AS companyName,
        [Legal Entity Name] AS legalEntityName,
        [Mailing Address] AS mailingAddress,
        [city] AS city,
        [state] AS state,
        [country] AS country,
        [postalCode] AS postalCode,
        [email] AS email,
        [Phone Number] AS phoneNumber,
        [Tax ID] AS taxId,
        [URL] AS url,
        [CompanyFolderID] AS companyFolderId,
        [ContractFolderID] AS contractFolderId,
        [UtilityBillsFolderID] AS utilityBillsFolderId,
        [isActive] AS isActive,
        [createdAt] AS createdAt,
        [updatedAt] AS updatedAt
      FROM dbo.tblCompany
      ORDER BY [updatedAt] DESC
    `);
    const companyIds = rows.map((row) => Number(row.id));
    const notes = companyIds.length ? await prisma.$queryRaw<Array<{ companyId: number; content: string }>>(Prisma.sql`
      SELECT [companyId], [content]
      FROM dbo.aae_notes
      WHERE [companyId] IN (${Prisma.join(companyIds)})
      ORDER BY [updatedAt] DESC
    `) : [];
    const notesByCompany = new Map<string, string>();
    for (const note of notes) {
      if (!notesByCompany.has(String(note.companyId))) notesByCompany.set(String(note.companyId), sanitizeCompanyNoteContent(note.content));
    }

    return res.json({
      total: Number(countRows[0]?.total ?? 0),
      data: rows.map((row) => ({ ...row, notes: notesByCompany.get(String(row.id)) ?? "" }))
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/tbl-companies/:id/documents", authorize("report:read"), async (req, res, next) => {
  try {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const company = await findTblCompanyById(id);
    if (!company) return res.status(404).json({ error: "Company not found" });

    const documents = await listCompanySharePointDocuments({
      companyFolderId: typeof company.companyFolderId === "string" ? company.companyFolderId : null,
      contractFolderId: typeof company.contractFolderId === "string" ? company.contractFolderId : null,
      utilityBillsFolderId: typeof company.utilityBillsFolderId === "string" ? company.utilityBillsFolderId : null
    });

    return res.json(documents);
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/sharepoint-files/:itemId/content", authorize("report:read"), async (req, res, next) => {
  try {
    const itemId = z.string().trim().min(1).parse(req.params.itemId);
    const file = await getSharePointFileContent(itemId);

    res.setHeader("Content-Type", file.contentType);
    res.setHeader("Content-Disposition", "inline");
    return res.send(file.buffer);
  } catch (error) {
    return next(error);
  }
});

const emptyStringToUndefined = (value: unknown) => {
  if (typeof value === "string" && value.trim() === "") return undefined;
  return value;
};

const optionalText = z.preprocess(emptyStringToUndefined, z.string().trim().optional());
const optionalPositiveInt = z.preprocess(emptyStringToUndefined, z.coerce.number().int().positive().optional());
const optionalDate = z.preprocess(emptyStringToUndefined, z.coerce.date().optional());

async function rawUnsafeRows<T>(query: string) {
  return await prisma.$queryRawUnsafe(query) as T[];
}

function requireMemberManager(role: string | undefined) {
  if (role !== "superadmin" && role !== "admin") {
    throw Object.assign(new Error("Only Superadmin and Admin can manage members."), { statusCode: 403 });
  }
}

const memberCreateSchema = z.object({
  firstName: z.string().trim().min(1),
  lastName: z.string().trim().min(1),
  email: z.string().trim().email(),
  phone: optionalText,
  companyId: optionalPositiveInt,
  company: optionalText,
  department: optionalText,
  designation: optionalText,
  memberType: z.enum(["admin", "member", "user"]).optional(),
  notes: z.string().max(10000).default(""),
  password: z.string().min(12)
});

reportsRoutes.get("/tbl-companies/:id/activities", authorize("company:read"), async (req, res, next) => {
  try {
    const companyId = z.coerce.number().int().positive().parse(req.params.id);
    const company = await findTblCompanyById(companyId);
    if (!company) return res.status(404).json({ error: "Company not found" });
    const orgId = req.user?.role === "superadmin" ? undefined : req.user?.orgId ?? undefined;
    const activities = await prisma.task.findMany({
      where: {
        relatedType: "tblCompanyActivity",
        relatedId: String(companyId),
        ...(orgId ? { orgId } : {})
      },
      orderBy: { createdAt: "desc" },
      include: { assignee: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    });
    return res.json({ company: { id: company.id, companyName: company.companyName }, data: await attachActivityConversation(activities) });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/tbl-companies/:id/activities", async (req, res, next) => {
  try {
    const companyId = z.coerce.number().int().positive().parse(req.params.id);
    const input = z.object({
      type: z.enum(["note", "todo"]),
      title: z.string().trim().min(1).max(200),
      description: z.string().trim().min(1).max(10000),
      assigneeId: z.string().trim().min(1),
      dueDate: z.preprocess(emptyStringToUndefined, z.coerce.date().optional()),
      priority: z.enum(["low", "medium", "high", "urgent"]).default("medium")
    }).parse(req.body);
    const company = await findTblCompanyById(companyId);
    if (!company) return res.status(404).json({ error: "Company not found" });

    const taggableRoles = req.user?.role === "admin"
      ? ["superadmin", "admin", "member"]
      : ["admin", "member", "user"];
    const assignee = await prisma.user.findFirst({
      where: {
        id: input.assigneeId,
        role: { in: taggableRoles },
        status: "active",
        ...(req.user?.role !== "superadmin" && req.user?.orgId ? { orgId: req.user.orgId } : {})
      },
      select: { id: true, orgId: true, email: true, firstName: true }
    });
    if (!assignee) return res.status(400).json({ error: "Select an active team member from your organization." });
    const orgId = req.user?.orgId ?? assignee.orgId;
    if (!orgId) return res.status(400).json({ error: "An organization is required to create an activity." });

    const activity = await prisma.task.create({
      data: {
        orgId,
        title: input.title,
        description: input.description,
        dueDate: input.type === "todo" ? input.dueDate : undefined,
        status: input.type === "note" ? "note" : "open",
        priority: input.type === "note" ? "note" : input.priority,
        assigneeId: assignee.id,
        relatedType: "tblCompanyActivity",
        relatedId: String(companyId)
      },
      include: { assignee: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    });
    await prisma.auditLog.create({
      data: {
        orgId,
        userId: req.user!.id,
        action: "tagged",
        module: "CompanyActivity",
        objectType: "companyActivity",
        objectId: activity.id,
        newValue: JSON.stringify({ companyId, assigneeId: assignee.id, type: input.type })
      }
    });
    if (assignee.id !== req.user!.id) {
      const companyName = String(company.companyName ?? `Company ${companyId}`);
      await prisma.notification.create({
        data: {
          userId: assignee.id,
          type: "company_activity",
          title: `${input.type === "todo" ? "To-do" : "Note"}: ${input.title}`,
          message: `You were tagged in an activity for ${companyName}.`,
          actionUrl: `/activity?companyId=${companyId}`
        }
      });
      try {
        await emailService.sendActivityAlert({
          email: assignee.email,
          firstName: assignee.firstName,
          subject: `New ${input.type === "todo" ? "to-do" : "note"}: ${input.title}`,
          heading: `You were tagged in ${companyName}`,
          message: input.description,
          actionPath: `/activity?companyId=${companyId}`
        });
      } catch (emailError) {
        console.error("Unable to send activity assignment email", emailError);
      }
    }
    return res.status(201).json({ data: activity });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/company-activities/:activityId/replies", async (req, res, next) => {
  try {
    const activityId = z.string().trim().min(1).parse(req.params.activityId);
    const input = z.object({ content: z.string().trim().min(1).max(5000) }).parse(req.body);
    const orgId = req.user?.role === "superadmin" ? undefined : req.user?.orgId ?? undefined;
    const activity = await prisma.task.findFirst({
      where: { id: activityId, relatedType: "tblCompanyActivity", ...(orgId ? { orgId } : {}) },
      select: { id: true, orgId: true, assigneeId: true, relatedId: true, title: true }
    });
    if (!activity) return res.status(404).json({ error: "Company activity not found" });
    const reply = await prisma.note.create({
      data: {
        orgId: activity.orgId,
        userId: req.user!.id,
        relatedType: "companyActivityReply",
        relatedId: activity.id,
        companyId: activity.relatedId ? Number(activity.relatedId) : null,
        content: sanitizeCompanyNoteContent(input.content)
      },
      include: { user: { select: { id: true, firstName: true, lastName: true, email: true, role: true } } }
    });
    const creatorEvent = await prisma.auditLog.findFirst({
      where: { objectType: "companyActivity", objectId: activity.id, action: "tagged" },
      orderBy: { createdAt: "asc" },
      select: { userId: true }
    });
    const recipientId = req.user!.id === activity.assigneeId ? creatorEvent?.userId : activity.assigneeId;
    if (recipientId && recipientId !== req.user!.id) {
      const recipient = await prisma.user.findUnique({
        where: { id: recipientId },
        select: { email: true, firstName: true }
      });
      await prisma.notification.create({
        data: {
          userId: recipientId,
          type: "company_activity_reply",
          title: `Reply: ${activity.title}`,
          message: input.content.trim().slice(0, 250),
          actionUrl: `/activity?companyId=${activity.relatedId}`
        }
      });
      if (recipient) {
        try {
          await emailService.sendActivityAlert({
            email: recipient.email,
            firstName: recipient.firstName,
            subject: `Activity reply: ${activity.title}`,
            heading: `A reply was added to ${activity.title}`,
            message: input.content.trim(),
            actionPath: `/activity?companyId=${activity.relatedId}`
          });
        } catch (emailError) {
          console.error("Unable to send activity reply email", emailError);
        }
      }
    }
    return res.status(201).json({ data: reply });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/company-activities/:activityId", async (req, res, next) => {
  try {
    const activityId = z.string().trim().min(1).parse(req.params.activityId);
    const input = z.object({ status: z.enum(["open", "completed"]) }).parse(req.body);
    const orgId = req.user?.role === "superadmin" ? undefined : req.user?.orgId ?? undefined;
    const existing = await prisma.task.findFirst({
      where: { id: activityId, relatedType: "tblCompanyActivity", status: { not: "note" }, ...(orgId ? { orgId } : {}) },
      select: { id: true }
    });
    if (!existing) return res.status(404).json({ error: "Company activity not found" });
    const activity = await prisma.task.update({ where: { id: activityId }, data: { status: input.status } });
    return res.json({ data: activity });
  } catch (error) {
    return next(error);
  }
});

const memberUpdateSchema = memberCreateSchema.extend({
  password: z.preprocess(emptyStringToUndefined, z.string().min(12).optional())
});

function manageableMemberWhere(id: string | undefined, user: { role: string; orgId: string | null } | undefined) {
  return {
    ...(id ? { id } : {}),
    role: { in: user?.role === "superadmin" ? ["admin", "user", "member"] : ["user", "member"] },
    status: { not: "deleted" },
    ...(user?.role !== "superadmin" && user?.orgId ? { orgId: user.orgId } : {})
  };
}

async function softDeleteMembers(
  ids: string[],
  user: { id: string; role: string; orgId: string | null } | undefined
) {
  const members = await prisma.user.findMany({
    where: { ...manageableMemberWhere(undefined, user), id: { in: ids } },
    select: { id: true }
  });
  if (!members.length) return 0;

  const memberIds = members.map((member) => member.id);
  const now = new Date();
  await prisma.$transaction([
    prisma.refreshToken.updateMany({
      where: { userId: { in: memberIds }, revoked: false },
      data: { revoked: true, revokedAt: now }
    }),
    prisma.userSession.updateMany({
      where: { userId: { in: memberIds }, revokedAt: null },
      data: { revokedAt: now }
    }),
    ...members.map((member) => prisma.user.update({
      where: { id: member.id },
      data: {
        email: `deleted+${member.id}@allamericanenergy.invalid`,
        username: null,
        status: "deleted",
        emailVerified: false,
        mustChangePassword: false,
        updatedBy: user?.id
      }
    }))
  ]);

  return members.length;
}

async function saveMemberNote(memberId: string, content: string, user: { id: string; orgId: string | null } | undefined) {
  const sanitizedContent = sanitizeCompanyNoteContent(content);
  const existing = await prisma.note.findFirst({
    where: { relatedType: "member", relatedId: memberId },
    orderBy: { updatedAt: "desc" },
    select: { id: true }
  });
  if (existing) {
    await prisma.note.update({ where: { id: existing.id }, data: { content: sanitizedContent } });
    return;
  }
  if (!sanitizedContent.replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, "").trim()) return;
  if (!user?.orgId) throw Object.assign(new Error("An organization is required to save member notes"), { statusCode: 400 });
  await prisma.note.create({
    data: { orgId: user.orgId, userId: user.id, relatedType: "member", relatedId: memberId, content: sanitizedContent }
  });
}

async function uniqueMemberLoginEmail(firstName: string, lastName: string) {
  const name = `${firstName}.${lastName}`.toLowerCase().replace(/[^a-z0-9.]/g, "").replace(/^\.+|\.+$/g, "") || "member";
  for (let suffix = 0; suffix < 1000; suffix += 1) {
    const candidate = `${name}${suffix || ""}@allamericanenergy.com`;
    const exists = await prisma.user.findFirst({
      where: { OR: [{ email: candidate }, { username: candidate }] },
      select: { id: true }
    });
    if (!exists) return candidate;
  }
  return `${name}.${Date.now()}@allamericanenergy.com`;
}

async function findTblContractById(id: number): Promise<Record<string, unknown> | undefined> {
  const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
    SELECT TOP (1)
      c.[id] AS id,
      c.[ContractID] AS contractId,
      cmc.[companyId] AS companyId,
      co.[Company Name] AS companyName,
      c.[Broker] AS brokerId,
      b.[Broker] AS broker,
      c.[Supplier] AS supplierId,
      s.[supplier] AS supplier,
      c.[Swing] AS swingId,
      c.[PassThrough] AS passThroughId,
      c.[BillType] AS billTypeId,
      c.[Rate-kWh/therms] AS rate,
      c.[Fee-kWh/Dth] AS fee,
      c.[Start Date] AS startDate,
      c.[End Date] AS endDate,
      c.[Months] AS months,
      c.[cFile] AS cFile,
      c.[isActive] AS isActive,
      c.[createdAt] AS createdAt,
      c.[updatedAt] AS updatedAt,
      c.[OnDate] AS onDate
    FROM dbo.tbl_Contract c
    OUTER APPLY (
      SELECT TOP (1) link.[CompanyID] AS companyId
      FROM dbo.tbl_CompanyMeterContract link
      WHERE link.[ContractID] = c.[id]
    ) cmc
    LEFT JOIN dbo.tblCompany co ON cmc.[companyId] = co.[id]
    LEFT JOIN dbo.tbl_Broker b ON c.[Broker] = b.[id]
    LEFT JOIN dbo.tbl_Supplier s ON c.[Supplier] = s.[id]
    WHERE c.[id] = ${id}
  `;

  const contract = rows[0];
  if (!contract) return undefined;
  const [note, swings, passThroughs, billTypes] = await Promise.all([
    prisma.note.findFirst({
      where: { relatedType: "contract", relatedId: String(id) },
      orderBy: { updatedAt: "desc" },
      select: { content: true }
    }),
    legacyLookupRows("tbl_Swing", ["Swing", "Type", "Name"]),
    legacyLookupRows("tbl_PassThrough", ["PassThrough", "Pass Through", "Type", "Name"]),
    legacyLookupRows("tbl_BillType", ["BillType", "Bill Type", "Type", "Name"])
  ]);
  const lookupName = (items: Array<Record<string, unknown>>, value: unknown) => items.find((item) => String(item.id) === String(value))?.name ?? null;
  return {
    ...contract,
    swing: lookupName(swings, contract.swingId),
    passThrough: lookupName(passThroughs, contract.passThroughId),
    billType: lookupName(billTypes, contract.billTypeId),
    notes: note ? sanitizeCompanyNoteContent(note.content) : ""
  };
}

reportsRoutes.get("/members", authorize("report:read"), async (req, res, next) => {
  try {
    const take = Math.min(Number(req.query.take ?? 100), 500);
    const companyId = req.query.companyId ? z.coerce.number().int().positive().parse(req.query.companyId) : null;
    const companyFilter = companyId ? String(companyId) : undefined;
    const where = {
      role: { in: req.user?.role === "superadmin" ? ["admin", "user", "member"] : ["user", "member"] },
      status: { not: "deleted" },
      ...(companyFilter ? { company: companyFilter } : {})
    };
    const [total, rows] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        take,
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          username: true,
          phone: true,
          company: true,
          department: true,
          designation: true,
          role: true,
          status: true,
          createdAt: true,
          updatedAt: true
        }
      })
    ]);

    const notes = rows.length ? await prisma.note.findMany({
      where: { relatedType: "member", relatedId: { in: rows.map((row) => row.id) } },
      orderBy: { updatedAt: "desc" },
      select: { relatedId: true, content: true }
    }) : [];
    const notesByMember = new Map<string, string>();
    for (const note of notes) {
      if (!notesByMember.has(note.relatedId)) notesByMember.set(note.relatedId, sanitizeCompanyNoteContent(note.content));
    }

    return res.json({
      total,
      data: rows.map((row: { company: string | null; role: string; status: string; [key: string]: unknown }) => ({
        ...row,
        companyId: row.company,
        loginEmail: row.username,
        roleName: row.role === "admin" ? "Admin" : row.role === "member" ? "Member" : "User",
        isActive: row.status === "active",
        notes: notesByMember.get(String(row.id)) ?? ""
      }))
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/members", authorize("company:create"), async (req, res, next) => {
  try {
    requireMemberManager(req.user?.role);
    const input = memberCreateSchema.parse(req.body);
    if (input.memberType === "admin" && req.user?.role !== "superadmin") {
      return res.status(403).json({ error: "Only Superadmin can create an Admin account." });
    }
    const deliveryEmail = input.email.toLowerCase();
    const existingDeliveryEmail = await prisma.user.findFirst({
      where: { OR: [{ email: deliveryEmail }, { username: deliveryEmail }] },
      select: { id: true }
    });
    if (existingDeliveryEmail) return res.status(409).json({ error: "A member with this email already exists" });
    await emailService.verifyConfiguration();
    const loginEmail = await uniqueMemberLoginEmail(input.firstName, input.lastName);
    const member = await prisma.user.create({
      data: {
        firstName: input.firstName,
        lastName: input.lastName,
        email: deliveryEmail,
        username: loginEmail,
        phone: input.phone ?? null,
        company: input.companyId ? String(input.companyId) : input.company ?? null,
        department: input.department ?? null,
        designation: input.designation ?? null,
        passwordHash: await bcrypt.hash(input.password, 12),
        role: input.memberType ?? "member",
        status: "active",
        emailVerified: true,
        mustChangePassword: true,
        orgId: req.user?.orgId ?? null,
        createdBy: req.user?.id
      },
      select: { id: true }
    });
    try {
      await emailService.sendMemberWelcome({
        email: deliveryEmail,
        firstName: input.firstName,
        loginEmail,
        temporaryPassword: input.password
      });
    } catch (emailError) {
      await prisma.user.delete({ where: { id: member.id } });
      throw emailError;
    }
    await saveMemberNote(member.id, input.notes, req.user);

    return res.status(201).json({ ok: true, loginEmail, emailSent: true });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/members/bulk-status", authorize("company:update"), async (req, res, next) => {
  try {
    requireMemberManager(req.user?.role);
    const input = z.object({
      ids: z.array(z.string().trim().min(1)).min(1).max(500).transform((ids) => Array.from(new Set(ids))),
      isActive: z.boolean()
    }).parse(req.body);
    const result = await prisma.user.updateMany({
      where: { ...manageableMemberWhere(undefined, req.user), id: { in: input.ids } },
      data: { status: input.isActive ? "active" : "inactive", updatedBy: req.user?.id }
    });
    return res.json({ updated: result.count, isActive: input.isActive });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.delete("/members/bulk", authorize("company:delete"), async (req, res, next) => {
  try {
    requireMemberManager(req.user?.role);
    const input = z.object({
      ids: z.array(z.string().trim().min(1)).min(1).max(500).transform((ids) => Array.from(new Set(ids)))
    }).parse(req.body);
    const deleted = await softDeleteMembers(input.ids, req.user);
    return res.json({ deleted });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/members/:id", authorize("company:update"), async (req, res, next) => {
  try {
    requireMemberManager(req.user?.role);
    const id = z.string().trim().min(1).parse(req.params.id);
    const member = await prisma.user.findFirst({ where: manageableMemberWhere(id, req.user), select: { id: true } });
    if (!member) return res.status(404).json({ error: "Member not found" });
    const input = memberUpdateSchema.parse(req.body);
    const deliveryEmail = input.email.toLowerCase();
    const duplicateEmail = await prisma.user.findFirst({
      where: { id: { not: id }, OR: [{ email: deliveryEmail }, { username: deliveryEmail }] },
      select: { id: true }
    });
    if (duplicateEmail) return res.status(409).json({ error: "A member with this email already exists" });
    await prisma.user.update({
      where: { id },
      data: {
        firstName: input.firstName,
        lastName: input.lastName,
        email: deliveryEmail,
        phone: input.phone ?? null,
        company: input.companyId ? String(input.companyId) : input.company ?? null,
        department: input.department ?? null,
        designation: input.designation ?? null,
        ...(input.password ? { passwordHash: await bcrypt.hash(input.password, 12) } : {}),
        updatedBy: req.user?.id
      }
    });
    await saveMemberNote(id, input.notes, req.user);
    return res.json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.delete("/members/:id", authorize("company:delete"), async (req, res, next) => {
  try {
    requireMemberManager(req.user?.role);
    const id = z.string().trim().min(1).parse(req.params.id);
    const deleted = await softDeleteMembers([id], req.user);
    if (!deleted) {
      const alreadyDeleted = await prisma.user.findFirst({
        where: { ...manageableMemberWhere(id, req.user), status: "deleted" },
        select: { id: true }
      });
      if (!alreadyDeleted) return res.status(404).json({ error: "Member not found" });
    }
    return res.status(204).send();
  } catch (error) {
    return next(error);
  }
});

async function findTblCompanyById(id: number): Promise<Record<string, unknown> | undefined> {
  const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
    SELECT TOP (1)
      [id] AS id,
      [organizationId] AS organizationId,
      [Customer ID] AS customerId,
      [Company Name] AS companyName,
      [Legal Entity Name] AS legalEntityName,
      [Mailing Address] AS mailingAddress,
      [city] AS city,
      [state] AS state,
      [country] AS country,
      [postalCode] AS postalCode,
      [email] AS email,
      [Phone Number] AS phoneNumber,
      [Tax ID] AS taxId,
      [URL] AS url,
      [CompanyFolderID] AS companyFolderId,
      [ContractFolderID] AS contractFolderId,
      [UtilityBillsFolderID] AS utilityBillsFolderId,
      [isActive] AS isActive,
      [createdAt] AS createdAt,
      [updatedAt] AS updatedAt
    FROM dbo.tblCompany
    WHERE [id] = ${id}
  `;

  const company = rows[0];
  if (!company) return undefined;
  const notes = await prisma.$queryRaw<Array<{ content: string }>>`
    SELECT TOP (1) [content]
    FROM dbo.aae_notes
    WHERE [companyId] = ${id}
    ORDER BY [updatedAt] DESC
  `;
  const note = notes[0];
  return { ...(company as Record<string, unknown>), notes: note ? sanitizeCompanyNoteContent(note.content) : "" };
}

async function resolveContractFolderId(company: Record<string, unknown> | null | undefined) {
  const existingContractFolderId = typeof company?.contractFolderId === "string" && company.contractFolderId.trim()
    ? company.contractFolderId
    : null;
  if (existingContractFolderId) return existingContractFolderId;

  const companyFolderId = typeof company?.companyFolderId === "string" && company.companyFolderId.trim()
    ? company.companyFolderId
    : null;
  if (!companyFolderId) return null;

  const contractFolderId = await ensureContractsFolder(companyFolderId);
  await prisma.$executeRaw`
    UPDATE dbo.tblCompany
    SET [ContractFolderID] = ${contractFolderId}
    WHERE [id] = ${Number(company?.id)}
  `;

  return contractFolderId;
}

async function upsertCompanyContractRelation(companyId: number | undefined, contractId: number, meterIds: number[] = []) {
  if (!companyId) return;

  if (meterIds.length) {
    await prisma.$executeRaw`
      DELETE FROM dbo.tbl_CompanyMeterContract
      WHERE [CompanyID] = ${companyId}
        AND [ContractID] = ${contractId}
    `;

    for (const meterId of meterIds) {
      await prisma.$executeRaw`
        INSERT INTO dbo.tbl_CompanyMeterContract ([MeterID], [CompanyID], [ContractID])
        VALUES (${meterId}, ${companyId}, ${contractId})
      `;
    }
    return;
  }

  const existingRows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
    SELECT TOP (1) [CompanyID] AS companyId
    FROM dbo.tbl_CompanyMeterContract
    WHERE [ContractID] = ${contractId}
  `;

  if (existingRows.length) {
    await prisma.$executeRaw`
      UPDATE dbo.tbl_CompanyMeterContract
      SET [CompanyID] = ${companyId}
      WHERE [ContractID] = ${contractId}
    `;
    return;
  }

  await prisma.$executeRaw`
    INSERT INTO dbo.tbl_CompanyMeterContract ([CompanyID], [ContractID])
    VALUES (${companyId}, ${contractId})
  `;
}

async function findTblMeterById(id: number): Promise<Record<string, unknown> | undefined> {
  const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
    SELECT TOP (1)
      m.[id] AS id,
      m.[Account Number] AS accountNumber,
      m.[Service Ref/POD] AS serviceRefPod,
      m.[Name Key] AS nameKey,
      m.[Meter] AS meter,
      m.[Service Address] AS serviceAddress,
      m.[City] AS city,
      m.[State] AS state,
      m.[Zip] AS zip,
      m.[Tax Exempt] AS taxExempt,
      m.[Cycle/Read Day] AS cycleReadDay,
      m.[Rate] AS rate,
      m.[Demand] AS demand,
      m.[Ann. Usage-Dth/kWh] AS annualUsage,
      m.[Load Profile] AS loadProfile,
      m.[iEnergyBill] AS iEnergyBill,
      m.[EnergyDashboard] AS energyDashboard,
      m.[OnSiteGeneration] AS onSiteGeneration,
      m.[CompanyID] AS companyId,
      co.[Company Name] AS companyName,
      m.[StatusId] AS statusId,
      st.[Status] AS status,
      m.[TypeId] AS typeId,
      t.[Type] AS type,
      m.[ProductId] AS productId,
      p.[Product] AS product,
      m.[UtilityId] AS utilityId,
      u.[Utility] AS utility,
      m.[IsActive] AS isActive,
      m.[CreatedAt] AS createdAt,
      m.[UpdatedAt] AS updatedAt
    FROM dbo.tbl_MeterList m
    LEFT JOIN dbo.tblCompany co ON m.[CompanyID] = co.[id]
    LEFT JOIN dbo.tbl_Type t ON m.[TypeId] = t.[id]
    LEFT JOIN dbo.tbl_Product p ON m.[ProductId] = p.[id]
    LEFT JOIN dbo.tbl_Utility u ON m.[UtilityId] = u.[id]
    LEFT JOIN dbo.tbl_Status st ON m.[StatusId] = st.[id]
    WHERE m.[id] = ${id}
  `;

  const meter = rows[0];
  if (!meter) return undefined;
  const note = await prisma.note.findFirst({
    where: { relatedType: "meter", relatedId: String(id) },
    orderBy: { updatedAt: "desc" },
    select: { content: true }
  });
  return { ...meter, notes: note ? sanitizeCompanyNoteContent(note.content) : "" };
}

async function findTblProductNameById(id: number) {
  const rows = await prisma.$queryRaw<Array<{ name: string }>>`
    SELECT TOP (1) [Product] AS [name]
    FROM dbo.tbl_Product
    WHERE [id] = ${id}
  `;
  return rows[0]?.name;
}

async function legacyLookupRows(tableName: string, preferredNameColumns: string[]) {
  const columns = await legacyTableColumns(tableName);
  const idColumn = columns.find((column) => column.primaryKey) ?? columns.find((column) => column.name.toLowerCase() === "id");
  const nameColumn = preferredNameColumns
    .map((name) => columns.find((column) => column.name.toLowerCase() === name.toLowerCase()))
    .find(Boolean) ?? columns.find((column) => column.editable && column.name !== idColumn?.name);
  if (!idColumn || !nameColumn) throw Object.assign(new Error(`${tableName} needs ID and display columns`), { statusCode: 500 });
  const table = Prisma.sql`${sqlIdentifier("dbo")}.${sqlIdentifier(tableName)}`;
  return prisma.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
    SELECT ${sqlIdentifier(idColumn.name)} AS [id], ${sqlIdentifier(nameColumn.name)} AS [name]
    FROM ${table}
    ORDER BY ${sqlIdentifier(nameColumn.name)}
  `);
}

async function legacyRateLookupRows() {
  const columns = await legacyTableColumns("tbl_Rate");
  const idColumn = columns.find((column) => column.primaryKey) ?? columns.find((column) => column.name.toLowerCase() === "id");
  const nameColumn = ["Rate", "Name"]
    .map((name) => columns.find((column) => column.name.toLowerCase() === name.toLowerCase()))
    .find(Boolean) ?? columns.find((column) => column.editable && column.name !== idColumn?.name);
  const utilityColumn = columns.find((column) => column.name.toLowerCase() === "utilityid");
  if (!idColumn || !nameColumn) throw Object.assign(new Error("tbl_Rate needs ID and display columns"), { statusCode: 500 });
  const table = Prisma.sql`${sqlIdentifier("dbo")}.${sqlIdentifier("tbl_Rate")}`;

  if (!utilityColumn) return legacyLookupRows("tbl_Rate", ["Rate", "Name"]);

  return prisma.$queryRaw<Array<Record<string, unknown>>>(Prisma.sql`
    SELECT
      ${sqlIdentifier(idColumn.name)} AS [id],
      ${sqlIdentifier(nameColumn.name)} AS [name],
      ${sqlIdentifier(utilityColumn.name)} AS [utilityId]
    FROM ${table}
    ORDER BY ${sqlIdentifier(utilityColumn.name)}, ${sqlIdentifier(nameColumn.name)}
  `);
}

reportsRoutes.get("/contract-lookups", authorize("report:read"), async (_req, res, next) => {
  try {
    const [brokers, suppliers, swings, passThroughs, billTypes, products] = await Promise.all([
      legacyLookupRows("tbl_Broker", ["Broker", "Name"]),
      legacyLookupRows("tbl_Supplier", ["Supplier", "Name"]),
      legacyLookupRows("tbl_Swing", ["Swing", "Type", "Name"]),
      legacyLookupRows("tbl_PassThrough", ["PassThrough", "Pass Through", "Type", "Name"]),
      legacyLookupRows("tbl_BillType", ["BillType", "Bill Type", "Type", "Name"]),
      legacyLookupRows("tbl_Product", ["Product", "Name"])
    ]);

    return res.json({ brokers, suppliers, swings, passThroughs, billTypes, products });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/contracts", authorize("report:read"), async (req, res, next) => {
  try {
    const take = Math.min(Number(req.query.take ?? 100), 500);
    const companyId = req.query.companyId ? z.coerce.number().int().positive().parse(req.query.companyId) : null;
    const whereClause = companyId ? `WHERE cmc.[companyId] = ${companyId}` : "";
    const contractCompanyApply = `
      OUTER APPLY (
        SELECT TOP (1) link.[CompanyID] AS companyId
        FROM dbo.tbl_CompanyMeterContract link
        WHERE link.[ContractID] = c.[id]
      ) cmc
    `;
    const countRows = await rawUnsafeRows<{ total: bigint | number }>(`
      SELECT COUNT(*) AS total
      FROM dbo.tbl_Contract c
      ${contractCompanyApply}
      ${whereClause}
    `);
    const rows = await rawUnsafeRows<Record<string, unknown>>(`
      SELECT TOP (${take})
        c.[id] AS id,
        c.[ContractID] AS contractId,
        cmc.[companyId] AS companyId,
        co.[Company Name] AS companyName,
        c.[Broker] AS brokerId,
        b.[Broker] AS broker,
        c.[Supplier] AS supplierId,
        s.[supplier] AS supplier,
        c.[Swing] AS swingId,
        c.[PassThrough] AS passThroughId,
        c.[BillType] AS billTypeId,
        c.[Rate-kWh/therms] AS rate,
        c.[Fee-kWh/Dth] AS fee,
        c.[Start Date] AS startDate,
        c.[End Date] AS endDate,
        c.[Months] AS months,
        c.[cFile] AS cFile,
        c.[isActive] AS isActive,
        c.[createdAt] AS createdAt,
        c.[updatedAt] AS updatedAt,
        c.[OnDate] AS onDate
      FROM dbo.tbl_Contract c
      ${contractCompanyApply}
      LEFT JOIN dbo.tblCompany co ON cmc.[companyId] = co.[id]
      LEFT JOIN dbo.tbl_Broker b ON c.[Broker] = b.[id]
      LEFT JOIN dbo.tbl_Supplier s ON c.[Supplier] = s.[id]
      ${whereClause}
      ORDER BY c.[updatedAt] DESC
    `);

    const contractIds = rows.map((row) => String(row.id));
    const [notes, swings, passThroughs, billTypes] = await Promise.all([
      contractIds.length ? prisma.note.findMany({
        where: { relatedType: "contract", relatedId: { in: contractIds } },
        orderBy: { updatedAt: "desc" },
        select: { relatedId: true, content: true }
      }) : [],
      legacyLookupRows("tbl_Swing", ["Swing", "Type", "Name"]),
      legacyLookupRows("tbl_PassThrough", ["PassThrough", "Pass Through", "Type", "Name"]),
      legacyLookupRows("tbl_BillType", ["BillType", "Bill Type", "Type", "Name"])
    ]);
    const notesByContract = new Map<string, string>();
    for (const note of notes) {
      if (!notesByContract.has(note.relatedId)) notesByContract.set(note.relatedId, sanitizeCompanyNoteContent(note.content));
    }

    const swingNames = new Map(swings.map((item) => [String(item.id), item.name]));
    const passThroughNames = new Map(passThroughs.map((item) => [String(item.id), item.name]));
    const billTypeNames = new Map(billTypes.map((item) => [String(item.id), item.name]));

    return res.json({
      total: Number(countRows[0]?.total ?? 0),
      data: rows.map((row) => ({
        ...row,
        swing: swingNames.get(String(row.swingId)) ?? null,
        passThrough: passThroughNames.get(String(row.passThroughId)) ?? null,
        billType: billTypeNames.get(String(row.billTypeId)) ?? null,
        notes: notesByContract.get(String(row.id)) ?? ""
      }))
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/meters", authorize("report:read"), async (req, res, next) => {
  try {
    const take = Math.min(Number(req.query.take ?? 100), 500);
    const companyId = req.query.companyId ? z.coerce.number().int().positive().parse(req.query.companyId) : null;
    const state = req.query.state ? z.string().trim().min(1).parse(req.query.state) : null;
    const utilityId = req.query.utilityId ? z.coerce.number().int().positive().parse(req.query.utilityId) : null;
    const productId = req.query.productId ? z.coerce.number().int().positive().parse(req.query.productId) : null;
    const filters = [
      companyId ? `m.[CompanyID] = ${companyId}` : null,
      state ? `m.[State] = '${state.replace(/'/g, "''")}'` : null,
      utilityId ? `m.[UtilityId] = ${utilityId}` : null,
      productId ? `m.[ProductId] = ${productId}` : null
    ].filter(Boolean);
    const whereClause = filters.length ? `WHERE ${filters.join(" AND ")}` : "";
    const countRows = await rawUnsafeRows<{ total: bigint | number }>(
      `SELECT COUNT(*) AS total FROM dbo.tbl_MeterList m ${whereClause}`
    );
    const rows = await rawUnsafeRows<Record<string, unknown>>(`
      SELECT TOP (${take})
        m.[id] AS id,
        m.[Account Number] AS accountNumber,
        m.[Service Ref/POD] AS serviceRefPod,
        m.[Name Key] AS nameKey,
        m.[Meter] AS meter,
        m.[Service Address] AS serviceAddress,
        m.[City] AS city,
        m.[State] AS state,
        m.[Zip] AS zip,
        m.[Tax Exempt] AS taxExempt,
        m.[Cycle/Read Day] AS cycleReadDay,
        m.[Rate] AS rate,
        m.[Demand] AS demand,
        m.[Ann. Usage-Dth/kWh] AS annualUsage,
        m.[Load Profile] AS loadProfile,
        m.[iEnergyBill] AS iEnergyBill,
        m.[EnergyDashboard] AS energyDashboard,
        m.[OnSiteGeneration] AS onSiteGeneration,
        m.[CompanyID] AS companyId,
        co.[Company Name] AS companyName,
        m.[StatusId] AS statusId,
        st.[Status] AS status,
        m.[TypeId] AS typeId,
        t.[Type] AS type,
        m.[ProductId] AS productId,
        p.[Product] AS product,
        m.[UtilityId] AS utilityId,
        u.[Utility] AS utility,
        m.[IsActive] AS isActive,
        m.[CreatedAt] AS createdAt,
        m.[UpdatedAt] AS updatedAt
      FROM dbo.tbl_MeterList m
      LEFT JOIN dbo.tblCompany co ON m.[CompanyID] = co.[id]
      LEFT JOIN dbo.tbl_Type t ON m.[TypeId] = t.[id]
      LEFT JOIN dbo.tbl_Product p ON m.[ProductId] = p.[id]
      LEFT JOIN dbo.tbl_Utility u ON m.[UtilityId] = u.[id]
      LEFT JOIN dbo.tbl_Status st ON m.[StatusId] = st.[id]
      ${whereClause}
      ORDER BY m.[UpdatedAt] DESC
    `);

    const meterIds = rows.map((row) => String(row.id));
    const notes = meterIds.length ? await prisma.note.findMany({
      where: { relatedType: "meter", relatedId: { in: meterIds } },
      orderBy: { updatedAt: "desc" },
      select: { relatedId: true, content: true }
    }) : [];
    const notesByMeter = new Map<string, string>();
    for (const note of notes) {
      if (!notesByMeter.has(note.relatedId)) notesByMeter.set(note.relatedId, sanitizeCompanyNoteContent(note.content));
    }

    return res.json({
      total: Number(countRows[0]?.total ?? 0),
      data: rows.map((row) => ({ ...row, notes: notesByMeter.get(String(row.id)) ?? "" }))
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/meter-lookups", authorize("report:read"), async (_req, res, next) => {
  try {
    const [iEnergyBills, energyDashboards, onSiteGenerations, types, products, utilities, statuses, taxExempts, rates] = await Promise.all([
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Type] AS name FROM dbo.tbl_iEnergyBill ORDER BY [Type]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Type] AS name FROM dbo.tbl_EnergyDashboard ORDER BY [Type]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Type] AS name FROM dbo.tbl_OnSiteGeneration ORDER BY [Type]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Type] AS name FROM dbo.tbl_Type ORDER BY [Type]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Product] AS name FROM dbo.tbl_Product ORDER BY [Product]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Utility] AS name FROM dbo.tbl_Utility ORDER BY [Utility]`,
      prisma.$queryRaw<Array<Record<string, unknown>>>`SELECT [id] AS id, [Status] AS name FROM dbo.tbl_Status ORDER BY [Status]`,
      legacyLookupRows("tbl_TaxExempt", ["TaxExempt", "Tax Exempt", "Type", "Name"]),
      legacyRateLookupRows()
    ]);

    return res.json({ iEnergyBills, energyDashboards, onSiteGenerations, types, products, utilities, statuses, taxExempts, rates });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/meter-state-product-utilities", authorize("report:read"), async (req, res, next) => {
  try {
    const state = z.string().trim().min(1).parse(req.query.state);
    const productId = req.query.productId ? z.coerce.number().int().positive().parse(req.query.productId) : null;
    const utilityId = req.query.utilityId ? z.coerce.number().int().positive().parse(req.query.utilityId) : null;

    const products = utilityId
      ? await prisma.$queryRaw<Array<Record<string, unknown>>>`
          SELECT DISTINCT
            p.[id] AS id,
            p.[Product] AS name
          FROM dbo.UtilityStateProduct usp
          INNER JOIN dbo.USStates s ON usp.[StateId] = s.[StateId]
          INNER JOIN dbo.tbl_Product p ON usp.[ProductId] = p.[id]
          WHERE usp.[UtilityId] = ${utilityId}
            AND (
              s.[StateCode] = ${state}
              OR s.[StateName] = ${state}
              OR CONVERT(varchar(20), s.[StateId]) = ${state}
            )
          ORDER BY p.[Product]
        `
      : await prisma.$queryRaw<Array<Record<string, unknown>>>`
          SELECT DISTINCT
            p.[id] AS id,
            p.[Product] AS name
          FROM dbo.UtilityStateProduct usp
          INNER JOIN dbo.USStates s ON usp.[StateId] = s.[StateId]
          INNER JOIN dbo.tbl_Product p ON usp.[ProductId] = p.[id]
          WHERE s.[StateCode] = ${state}
             OR s.[StateName] = ${state}
             OR CONVERT(varchar(20), s.[StateId]) = ${state}
          ORDER BY p.[Product]
        `;

    const utilities = productId
      ? await prisma.$queryRaw<Array<Record<string, unknown>>>`
          SELECT DISTINCT
            u.[id] AS id,
            u.[Utility] AS name
          FROM dbo.UtilityStateProduct usp
          INNER JOIN dbo.USStates s ON usp.[StateId] = s.[StateId]
          INNER JOIN dbo.tbl_Utility u ON usp.[UtilityId] = u.[id]
          WHERE usp.[ProductId] = ${productId}
            AND (
              s.[StateCode] = ${state}
              OR s.[StateName] = ${state}
              OR CONVERT(varchar(20), s.[StateId]) = ${state}
            )
          ORDER BY u.[Utility]
        `
      : await prisma.$queryRaw<Array<Record<string, unknown>>>`
          SELECT DISTINCT
            u.[id] AS id,
            u.[Utility] AS name
          FROM dbo.UtilityStateProduct usp
          INNER JOIN dbo.USStates s ON usp.[StateId] = s.[StateId]
          INNER JOIN dbo.tbl_Utility u ON usp.[UtilityId] = u.[id]
          WHERE s.[StateCode] = ${state}
             OR s.[StateName] = ${state}
             OR CONVERT(varchar(20), s.[StateId]) = ${state}
          ORDER BY u.[Utility]
        `;

    return res.json({ products, utilities });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/us-states", authorize("report:read"), async (_req, res, next) => {
  try {
    const states = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT
        [StateId] AS id,
        [StateName] AS name,
        [StateCode] AS code
      FROM dbo.USStates
      ORDER BY [StateName]
    `;

    return res.json({ data: states });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/us-cities", authorize("report:read"), async (req, res, next) => {
  try {
    const state = z.string().trim().min(1).parse(req.query.state);
    const cities = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT DISTINCT
        c.[CityId] AS id,
        c.[CityName] AS name
      FROM dbo.USCities c
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      WHERE s.[StateCode] = ${state}
         OR s.[StateName] = ${state}
         OR CONVERT(varchar(20), s.[StateId]) = ${state}
      ORDER BY c.[CityName]
    `;

    return res.json({ data: cities });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/zip-code-details", authorize("report:read"), async (req, res, next) => {
  try {
    const zip = z.string().trim().min(1).max(20).parse(req.query.zip);
    const zipPrefix = `${zip}%`;
    const matches = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT TOP (50)
        z.[ZipId] AS id,
        z.[ZipCode] AS code,
        c.[CityName] AS city,
        s.[StateCode] AS state,
        s.[StateName] AS stateName
      FROM dbo.ZipCodes z
      INNER JOIN dbo.USCities c ON z.[CityId] = c.[CityId]
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      WHERE CONVERT(varchar(20), z.[ZipCode]) LIKE ${zipPrefix}
      ORDER BY z.[ZipCode], c.[CityName]
    `;

    return res.json({ data: matches });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/zip-codes", authorize("report:read"), async (req, res, next) => {
  try {
    const state = z.string().trim().min(1).parse(req.query.state);
    const city = z.string().trim().min(1).parse(req.query.city);
    const zipCodes = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT DISTINCT
        z.[ZipId] AS id,
        z.[ZipCode] AS code
      FROM dbo.ZipCodes z
      INNER JOIN dbo.USCities c ON z.[CityId] = c.[CityId]
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      WHERE c.[CityName] = ${city}
        AND (
          s.[StateCode] = ${state}
          OR s.[StateName] = ${state}
          OR CONVERT(varchar(20), s.[StateId]) = ${state}
        )
      ORDER BY z.[ZipCode]
    `;

    return res.json({ data: zipCodes });
  } catch (error) {
    return next(error);
  }
});

const locationStateSchema = z.object({
  name: z.string().trim().min(1, "State name is required").max(100),
  code: z.string().trim().length(2, "State code must be 2 characters").transform((value) => value.toUpperCase()),
  capital: z.string().trim().min(1, "Capital is required").max(100)
});

const locationCitySchema = z.object({
  stateId: z.coerce.number().int().positive(),
  name: z.string().trim().min(1, "City name is required").max(150),
  isCapital: z.boolean().default(false)
});

const locationZipSchema = z.object({
  cityId: z.coerce.number().int().positive(),
  code: z.string().trim().min(1, "ZIP code is required").max(10),
  isActive: z.boolean().default(true)
});

const uploadedCitySchema = z.object({
  state: z.string().trim().min(1, "State is required"),
  city: z.string().trim().min(1, "City is required").max(150),
  isCapital: z.boolean().default(false)
});

const uploadedZipSchema = z.object({
  state: z.string().trim().min(1, "State is required"),
  city: z.string().trim().min(1, "City is required").max(150),
  zip: z.string().trim().min(1, "ZIP is required").max(10),
  isActive: z.boolean().default(true)
});

async function locationStateId(
  transaction: Prisma.TransactionClient,
  state: string
) {
  const rows = await transaction.$queryRaw<Array<{ id: number }>>`
    SELECT TOP (1) [StateId] AS id
    FROM dbo.USStates WITH (UPDLOCK, HOLDLOCK)
    WHERE [StateCode] = ${state}
       OR [StateName] = ${state}
       OR CONVERT(varchar(20), [StateId]) = ${state}
    ORDER BY [StateId]
  `;
  if (!rows[0]) throw Object.assign(new Error(`State "${state}" was not found`), { statusCode: 400 });
  return rows[0].id;
}

async function findOrCreateLocationCity(
  transaction: Prisma.TransactionClient,
  stateId: number,
  city: string,
  isCapital = false
) {
  let rows = await transaction.$queryRaw<Array<{ id: number; created: number }>>`
    SELECT TOP (1) [CityId] AS id, 0 AS created
    FROM dbo.USCities WITH (UPDLOCK, HOLDLOCK)
    WHERE [StateId] = ${stateId} AND LOWER([CityName]) = LOWER(${city})
    ORDER BY [CityId]
  `;
  if (!rows[0]) {
    rows = await transaction.$queryRaw<Array<{ id: number; created: number }>>`
      INSERT INTO dbo.USCities ([StateId], [CityName], [IsCapital], [OnDate])
      OUTPUT INSERTED.[CityId] AS id, 1 AS created
      VALUES (${stateId}, ${city}, ${isCapital}, ${new Date()})
    `;
  }
  if (!rows[0]) throw new Error("City was inserted but its ID was not returned");
  return rows[0];
}

reportsRoutes.get("/location-states", authorize("org:administer"), async (_req, res, next) => {
  try {
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT [StateId] AS id, [StateName] AS name, [StateCode] AS code, [Capital] AS capital, [OnDate] AS onDate
      FROM dbo.USStates
      ORDER BY [StateName]
    `;
    return res.json({ total: rows.length, data: rows });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-states", authorize("org:administer"), async (req, res, next) => {
  try {
    const input = locationStateSchema.parse(req.body);
    const existing = await prisma.$queryRaw<Array<{ id: number }>>`
      SELECT TOP (1) [StateId] AS id FROM dbo.USStates
      WHERE [StateCode] = ${input.code} OR LOWER([StateName]) = LOWER(${input.name})
    `;
    if (existing[0]) return res.status(409).json({ error: "State already exists" });
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      INSERT INTO dbo.USStates ([StateName], [StateCode], [Capital], [OnDate])
      OUTPUT INSERTED.[StateId] AS id, INSERTED.[StateName] AS name, INSERTED.[StateCode] AS code, INSERTED.[Capital] AS capital
      VALUES (${input.name}, ${input.code}, ${input.capital}, ${new Date()})
    `;
    return res.status(201).json({ data: rows[0] });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-states/bulk", authorize("org:administer"), async (req, res, next) => {
  try {
    const rows = z.object({ rows: z.array(locationStateSchema).min(1).max(500) }).parse(req.body).rows;
    const result = await prisma.$transaction(async (transaction) => {
      let imported = 0;
      let existing = 0;
      for (const row of rows) {
        const found = await transaction.$queryRaw<Array<{ id: number }>>`
          SELECT TOP (1) [StateId] AS id FROM dbo.USStates WITH (UPDLOCK, HOLDLOCK)
          WHERE [StateCode] = ${row.code} OR LOWER([StateName]) = LOWER(${row.name})
        `;
        if (found[0]) {
          existing += 1;
          continue;
        }
        await transaction.$executeRaw`
          INSERT INTO dbo.USStates ([StateName], [StateCode], [Capital], [OnDate])
          VALUES (${row.name}, ${row.code}, ${row.capital}, ${new Date()})
        `;
        imported += 1;
      }
      return { imported, existing };
    });
    return res.status(201).json({ total: rows.length, ...result });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/location-cities", authorize("org:administer"), async (req, res, next) => {
  try {
    const take = Math.min(Math.max(Number(req.query.take ?? 1000) || 1000, 1), 2000);
    const countRows = await prisma.$queryRaw<Array<{ total: bigint | number }>>`SELECT COUNT(*) AS total FROM dbo.USCities`;
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT TOP (${take})
        c.[CityId] AS id, c.[CityName] AS name, c.[StateId] AS stateId,
        s.[StateCode] AS state, s.[StateName] AS stateName, c.[IsCapital] AS isCapital, c.[OnDate] AS onDate
      FROM dbo.USCities c
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      ORDER BY s.[StateName], c.[CityName]
    `;
    return res.json({ total: Number(countRows[0]?.total ?? 0), data: rows });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-cities", authorize("org:administer"), async (req, res, next) => {
  try {
    const input = locationCitySchema.parse(req.body);
    const state = await prisma.$queryRaw<Array<{ id: number }>>`SELECT TOP (1) [StateId] AS id FROM dbo.USStates WHERE [StateId] = ${input.stateId}`;
    if (!state[0]) return res.status(400).json({ error: "Selected state was not found" });
    const existing = await prisma.$queryRaw<Array<{ id: number }>>`
      SELECT TOP (1) [CityId] AS id FROM dbo.USCities
      WHERE [StateId] = ${input.stateId} AND LOWER([CityName]) = LOWER(${input.name})
    `;
    if (existing[0]) return res.status(409).json({ error: "City already exists in this state" });
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      INSERT INTO dbo.USCities ([StateId], [CityName], [IsCapital], [OnDate])
      OUTPUT INSERTED.[CityId] AS id, INSERTED.[CityName] AS name, INSERTED.[StateId] AS stateId, INSERTED.[IsCapital] AS isCapital
      VALUES (${input.stateId}, ${input.name}, ${input.isCapital}, ${new Date()})
    `;
    return res.status(201).json({ data: rows[0] });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-cities/bulk", authorize("org:administer"), async (req, res, next) => {
  try {
    const rows = z.object({ rows: z.array(uploadedCitySchema).min(1).max(1000) }).parse(req.body).rows;
    const result = await prisma.$transaction(async (transaction) => {
      let imported = 0;
      let existing = 0;
      for (const row of rows) {
        const stateId = await locationStateId(transaction, row.state);
        const city = await findOrCreateLocationCity(transaction, stateId, row.city, row.isCapital);
        city.created ? imported += 1 : existing += 1;
      }
      return { imported, existing };
    });
    return res.status(201).json({ total: rows.length, ...result });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.get("/location-zip-codes", authorize("org:administer"), async (req, res, next) => {
  try {
    const take = Math.min(Math.max(Number(req.query.take ?? 1000) || 1000, 1), 2000);
    const countRows = await prisma.$queryRaw<Array<{ total: bigint | number }>>`SELECT COUNT(*) AS total FROM dbo.ZipCodes`;
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      SELECT TOP (${take})
        z.[ZipId] AS id, z.[ZipCode] AS code, z.[CityId] AS cityId, c.[CityName] AS city,
        s.[StateId] AS stateId, s.[StateCode] AS state, s.[StateName] AS stateName,
        z.[IsActive] AS isActive, z.[OnDate] AS onDate
      FROM dbo.ZipCodes z
      INNER JOIN dbo.USCities c ON z.[CityId] = c.[CityId]
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      ORDER BY z.[ZipCode], s.[StateCode], c.[CityName]
    `;
    return res.json({ total: Number(countRows[0]?.total ?? 0), data: rows });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-zip-codes", authorize("org:administer"), async (req, res, next) => {
  try {
    const input = locationZipSchema.parse(req.body);
    const city = await prisma.$queryRaw<Array<{ id: number }>>`SELECT TOP (1) [CityId] AS id FROM dbo.USCities WHERE [CityId] = ${input.cityId}`;
    if (!city[0]) return res.status(400).json({ error: "Selected city was not found" });
    const existing = await prisma.$queryRaw<Array<{ id: number }>>`
      SELECT TOP (1) [ZipId] AS id FROM dbo.ZipCodes WHERE [CityId] = ${input.cityId} AND [ZipCode] = ${input.code}
    `;
    if (existing[0]) return res.status(409).json({ error: "ZIP code already exists for this city" });
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      INSERT INTO dbo.ZipCodes ([CityId], [ZipCode], [IsActive], [OnDate])
      OUTPUT INSERTED.[ZipId] AS id, INSERTED.[ZipCode] AS code, INSERTED.[CityId] AS cityId, INSERTED.[IsActive] AS isActive
      VALUES (${input.cityId}, ${input.code}, ${input.isActive}, ${new Date()})
    `;
    return res.status(201).json({ data: rows[0] });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/location-zip-codes/bulk", authorize("org:administer"), async (req, res, next) => {
  try {
    const rows = z.object({ rows: z.array(uploadedZipSchema).min(1).max(1000) }).parse(req.body).rows;
    const result = await prisma.$transaction(async (transaction) => {
      let imported = 0;
      let existing = 0;
      let citiesCreated = 0;
      for (const row of rows) {
        const stateId = await locationStateId(transaction, row.state);
        const city = await findOrCreateLocationCity(transaction, stateId, row.city);
        if (city.created) citiesCreated += 1;
        const found = await transaction.$queryRaw<Array<{ id: number }>>`
          SELECT TOP (1) [ZipId] AS id FROM dbo.ZipCodes WITH (UPDLOCK, HOLDLOCK)
          WHERE [CityId] = ${city.id} AND [ZipCode] = ${row.zip}
        `;
        if (found[0]) {
          existing += 1;
          continue;
        }
        await transaction.$executeRaw`
          INSERT INTO dbo.ZipCodes ([CityId], [ZipCode], [IsActive], [OnDate])
          VALUES (${city.id}, ${row.zip}, ${row.isActive}, ${new Date()})
        `;
        imported += 1;
      }
      return { imported, existing, citiesCreated };
    });
    return res.status(201).json({ total: rows.length, ...result });
  } catch (error) {
    return next(error);
  }
});

const tblMeterCreateSchema = z.object({
  companyId: z.coerce.number().int().positive(),
  accountNumber: optionalText,
  serviceRefPod: optionalText,
  nameKey: optionalText,
  meter: optionalText,
  serviceAddress: optionalText,
  city: z.preprocess(emptyStringToUndefined, z.string().trim().max(150).optional()),
  state: z.preprocess(emptyStringToUndefined, z.string().trim().max(100).optional()),
  zip: z.preprocess(emptyStringToUndefined, z.string().trim().max(10).optional()),
  taxExempt: optionalPositiveInt,
  cycleReadDay: optionalText,
  rate: optionalPositiveInt,
  demand: optionalText,
  annualUsage: optionalText,
  loadProfile: optionalText,
  iEnergyBillId: optionalPositiveInt,
  energyDashboardId: optionalPositiveInt,
  onSiteGenerationId: optionalPositiveInt,
  typeId: optionalPositiveInt,
  productId: optionalPositiveInt,
  utilityId: optionalPositiveInt,
  statusId: optionalPositiveInt,
  notes: z.string().max(10000).optional(),
  isActive: z.boolean().default(true)
});

const tblMeterUpdateSchema = tblMeterCreateSchema.partial();

const meterLocationSchema = z.object({
  zip: z.string().trim().min(1, "ZIP code is required").max(10),
  city: z.string().trim().min(1, "City is required").max(150),
  state: z.string().trim().min(1, "State is required").max(100)
});

type MeterLocation = {
  zip: string;
  city: string;
  state: string;
  stateId: number;
  cityId: number;
  zipId: number;
  createdCity: boolean;
  createdZip: boolean;
};

function locationError(message: string) {
  return Object.assign(new Error(message), { statusCode: 400 });
}

async function ensureMeterLocation(input: {
  zip?: string | null;
  city?: string | null;
  state?: string | null;
}): Promise<MeterLocation | null> {
  const zip = input.zip?.trim();
  const city = input.city?.trim();
  const state = input.state?.trim();
  if (!zip) return null;

  // Existing ZIPs remain usable by older clients that only submit the ZIP.
  if (!city || !state) {
    const existing = await prisma.$queryRaw<Array<{
      zipId: number;
      cityId: number;
      stateId: number;
      zip: string;
      city: string;
      state: string;
    }>>`
      SELECT TOP (1)
        z.[ZipId] AS zipId,
        c.[CityId] AS cityId,
        s.[StateId] AS stateId,
        z.[ZipCode] AS zip,
        c.[CityName] AS city,
        s.[StateCode] AS state
      FROM dbo.ZipCodes z
      INNER JOIN dbo.USCities c ON z.[CityId] = c.[CityId]
      INNER JOIN dbo.USStates s ON c.[StateId] = s.[StateId]
      WHERE z.[ZipCode] = ${zip}
      ORDER BY z.[ZipId]
    `;
    if (!existing[0]) {
      throw locationError("This ZIP code is not available. Enter its city and state to add it.");
    }
    return { ...existing[0], createdCity: false, createdZip: false };
  }

  return prisma.$transaction(async (transaction) => {
    const states = await transaction.$queryRaw<Array<{
      stateId: number;
      state: string;
    }>>`
      SELECT TOP (1)
        [StateId] AS stateId,
        [StateCode] AS state
      FROM dbo.USStates WITH (UPDLOCK, HOLDLOCK)
      WHERE [StateCode] = ${state}
         OR [StateName] = ${state}
         OR CONVERT(varchar(20), [StateId]) = ${state}
      ORDER BY [StateId]
    `;
    const matchedState = states[0];
    if (!matchedState) {
      throw locationError("State was not found. Select a valid U.S. state.");
    }

    let createdCity = false;
    let cities = await transaction.$queryRaw<Array<{ cityId: number; city: string }>>`
      SELECT TOP (1)
        [CityId] AS cityId,
        [CityName] AS city
      FROM dbo.USCities WITH (UPDLOCK, HOLDLOCK)
      WHERE [StateId] = ${matchedState.stateId}
        AND LOWER([CityName]) = LOWER(${city})
      ORDER BY [CityId]
    `;
    if (!cities[0]) {
      cities = await transaction.$queryRaw<Array<{ cityId: number; city: string }>>`
        INSERT INTO dbo.USCities ([StateId], [CityName], [IsCapital], [OnDate])
        OUTPUT INSERTED.[CityId] AS cityId, INSERTED.[CityName] AS city
        VALUES (${matchedState.stateId}, ${city}, ${false}, ${new Date()})
      `;
      createdCity = true;
    }
    const matchedCity = cities[0];
    if (!matchedCity) throw new Error("City was inserted but its ID was not returned");

    let createdZip = false;
    let zipCodes = await transaction.$queryRaw<Array<{ zipId: number; zip: string }>>`
      SELECT TOP (1)
        [ZipId] AS zipId,
        [ZipCode] AS zip
      FROM dbo.ZipCodes WITH (UPDLOCK, HOLDLOCK)
      WHERE [CityId] = ${matchedCity.cityId}
        AND [ZipCode] = ${zip}
      ORDER BY [ZipId]
    `;
    if (!zipCodes[0]) {
      zipCodes = await transaction.$queryRaw<Array<{ zipId: number; zip: string }>>`
        INSERT INTO dbo.ZipCodes ([CityId], [ZipCode], [IsActive], [OnDate])
        OUTPUT INSERTED.[ZipId] AS zipId, INSERTED.[ZipCode] AS zip
        VALUES (${matchedCity.cityId}, ${zip}, ${true}, ${new Date()})
      `;
      createdZip = true;
    }
    const matchedZip = zipCodes[0];
    if (!matchedZip) throw new Error("ZIP code was inserted but its ID was not returned");

    return {
      ...matchedZip,
      ...matchedCity,
      stateId: matchedState.stateId,
      state: matchedState.state,
      createdCity,
      createdZip
    };
  });
}

reportsRoutes.post("/meter-locations", authorize("company:create"), async (req, res, next) => {
  try {
    const input = meterLocationSchema.parse(req.body);
    const location = await ensureMeterLocation(input);
    return res.status(location?.createdCity || location?.createdZip ? 201 : 200).json({ data: location });
  } catch (error) {
    return next(error);
  }
});

async function saveMeterNote(meterId: number, content: string | undefined, user: { id: string; orgId: string | null } | undefined) {
  if (content === undefined) return;
  const sanitizedContent = sanitizeCompanyNoteContent(content);
  const existing = await prisma.note.findFirst({
    where: { relatedType: "meter", relatedId: String(meterId) },
    orderBy: { updatedAt: "desc" },
    select: { id: true }
  });
  if (existing) {
    await prisma.note.update({ where: { id: existing.id }, data: { content: sanitizedContent } });
    return;
  }
  if (!sanitizedContent.replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, "").trim()) return;
  if (!user?.orgId) throw Object.assign(new Error("An organization is required to save meter notes"), { statusCode: 400 });
  await prisma.note.create({
    data: { orgId: user.orgId, userId: user.id, relatedType: "meter", relatedId: String(meterId), content: sanitizedContent }
  });
}

async function createTblMeter(input: z.infer<typeof tblMeterCreateSchema>, user: { id: string; orgId: string | null } | undefined) {
  const location = await ensureMeterLocation(input);
  const now = new Date();
  const rows = await prisma.$queryRaw<Array<{ id: number }>>`
      INSERT INTO dbo.tbl_MeterList (
        [Account Number],
        [Service Ref/POD],
        [Name Key],
        [Meter],
        [Service Address],
        [City],
        [State],
        [Zip],
        [Tax Exempt],
        [Cycle/Read Day],
        [Rate],
        [Demand],
        [Ann. Usage-Dth/kWh],
        [Load Profile],
        [iEnergyBill],
        [EnergyDashboard],
        [OnSiteGeneration],
        [CompanyID],
        [StatusId],
        [TypeId],
        [ProductId],
        [UtilityId],
        [IsActive],
        [CreatedAt],
        [UpdatedAt]
      )
      OUTPUT INSERTED.[id] AS id
      VALUES (
        ${input.accountNumber ?? null},
        ${input.serviceRefPod ?? null},
        ${input.nameKey ?? null},
        ${input.meter ?? null},
        ${input.serviceAddress ?? null},
        ${location?.city ?? input.city ?? null},
        ${location?.state ?? input.state ?? null},
        ${location?.zip ?? input.zip ?? null},
        ${input.taxExempt ?? null},
        ${input.cycleReadDay ?? null},
        ${input.rate ?? null},
        ${input.demand ?? null},
        ${input.annualUsage ?? null},
        ${input.loadProfile ?? null},
        ${input.iEnergyBillId ?? null},
        ${input.energyDashboardId ?? null},
        ${input.onSiteGenerationId ?? null},
        ${input.companyId},
        ${input.statusId ?? null},
        ${input.typeId ?? null},
        ${input.productId ?? null},
        ${input.utilityId ?? null},
        ${input.isActive},
        ${now},
        ${now}
      )
    `;

  const meterId = Number(rows[0]?.id);
  if (!meterId) throw new Error("Meter was inserted but its ID was not returned");
  await saveMeterNote(meterId, input.notes, user);
  return { data: await findTblMeterById(meterId) };
}

reportsRoutes.post("/meters", authorize("company:create"), async (req, res, next) => {
  try {
    const input = tblMeterCreateSchema.parse(req.body);
    return res.status(201).json(await createTblMeter(input, req.user));
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/meters/bulk", authorize("company:create"), async (req, res, next) => {
  try {
    const request = z.object({
      companyId: z.coerce.number().int().positive(),
      meters: z.array(z.unknown()).min(1).max(500)
    }).parse(req.body);
    const companyRows = await prisma.$queryRaw<Array<{ id: number; isActive: boolean }>>`
      SELECT TOP (1) [id], [isActive] FROM dbo.tblCompany WHERE [id] = ${request.companyId}
    `;
    if (!companyRows[0]) return res.status(404).json({ error: "Company not found" });
    if (!companyRows[0].isActive) return res.status(409).json({ error: "Make company active to add meters." });

    const imported: Array<{ row: number; id: string | number | undefined; meter: string }> = [];
    const errors: Array<{ row: number; meter: string; error: string }> = [];

    for (const [index, candidate] of request.meters.entries()) {
      const row = index + 2;
      const candidateObject = candidate && typeof candidate === "object" ? candidate as Record<string, unknown> : {};
      const meterLabel = String(candidateObject.meter ?? candidateObject.accountNumber ?? "").trim();
      if (!String(candidateObject.meter ?? "").trim() && !String(candidateObject.accountNumber ?? "").trim()) {
        errors.push({ row, meter: meterLabel, error: "Account Number or Meter is required" });
        continue;
      }
      const parsed = tblMeterCreateSchema.safeParse({ ...candidateObject, companyId: request.companyId });
      if (!parsed.success) {
        errors.push({ row, meter: meterLabel, error: parsed.error.issues[0]?.message ?? "Invalid meter data" });
        continue;
      }

      try {
        const result = await createTblMeter(parsed.data, req.user);
        imported.push({
          row,
          id: result.data?.id == null ? undefined : String(result.data.id),
          meter: parsed.data.meter ?? parsed.data.accountNumber ?? ""
        });
      } catch (error) {
        errors.push({ row, meter: meterLabel, error: error instanceof Error ? error.message : "Unable to create meter" });
      }
    }

    return res.status(errors.length ? 207 : 201).json({
      total: request.meters.length,
      imported: imported.length,
      failed: errors.length,
      data: imported,
      errors
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/meters/bulk-status", authorize("company:update"), async (req, res, next) => {
  try {
    const input = z.object({
      ids: z.array(z.coerce.number().int().positive()).min(1).max(500)
        .transform((ids) => Array.from(new Set(ids))),
      isActive: z.boolean()
    }).parse(req.body);

    const updated = await prisma.$executeRaw(Prisma.sql`
      UPDATE dbo.tbl_MeterList
      SET [IsActive] = ${input.isActive}, [UpdatedAt] = ${new Date()}
      WHERE [id] IN (${Prisma.join(input.ids)})
    `);

    return res.json({ updated, isActive: input.isActive });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/meters/:id", authorize("company:update"), async (req, res, next) => {
  try {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const current = await findTblMeterById(id);
    if (!current) return res.status(404).json({ error: "Meter not found" });

    const input = tblMeterUpdateSchema.parse(req.body);
    const locationChanged = input.zip !== undefined || input.city !== undefined || input.state !== undefined;
    const location = locationChanged
      ? await ensureMeterLocation({
          zip: input.zip ?? String(current.zip ?? ""),
          city: input.city ?? String(current.city ?? ""),
          state: input.state ?? String(current.state ?? "")
        })
      : null;
    await prisma.$executeRaw`
      UPDATE dbo.tbl_MeterList
      SET
        [Account Number] = ${input.accountNumber ?? current.accountNumber ?? null},
        [Service Ref/POD] = ${input.serviceRefPod ?? current.serviceRefPod ?? null},
        [Name Key] = ${input.nameKey ?? current.nameKey ?? null},
        [Meter] = ${input.meter ?? current.meter ?? null},
        [Service Address] = ${input.serviceAddress ?? current.serviceAddress ?? null},
        [City] = ${location?.city ?? input.city ?? current.city ?? null},
        [State] = ${location?.state ?? input.state ?? current.state ?? null},
        [Zip] = ${location?.zip ?? input.zip ?? current.zip ?? null},
        [Tax Exempt] = ${input.taxExempt ?? current.taxExempt ?? null},
        [Cycle/Read Day] = ${input.cycleReadDay ?? current.cycleReadDay ?? null},
        [Rate] = ${input.rate ?? current.rate ?? null},
        [Demand] = ${input.demand ?? current.demand ?? null},
        [Ann. Usage-Dth/kWh] = ${input.annualUsage ?? current.annualUsage ?? null},
        [Load Profile] = ${input.loadProfile ?? current.loadProfile ?? null},
        [iEnergyBill] = ${input.iEnergyBillId ?? current.iEnergyBill ?? null},
        [EnergyDashboard] = ${input.energyDashboardId ?? current.energyDashboard ?? null},
        [OnSiteGeneration] = ${input.onSiteGenerationId ?? current.onSiteGeneration ?? null},
        [CompanyID] = ${input.companyId ?? current.companyId ?? null},
        [StatusId] = ${input.statusId ?? current.statusId ?? null},
        [TypeId] = ${input.typeId ?? current.typeId ?? null},
        [ProductId] = ${input.productId ?? current.productId ?? null},
        [UtilityId] = ${input.utilityId ?? current.utilityId ?? null},
        [IsActive] = ${input.isActive ?? current.isActive},
        [UpdatedAt] = ${new Date()}
      WHERE [id] = ${id}
    `;

    await saveMeterNote(id, input.notes, req.user);
    return res.json({ data: await findTblMeterById(id) });
  } catch (error) {
    return next(error);
  }
});

const tblContractBaseSchema = z.object({
  companyId: z.coerce.number().int().positive("Company is required"),
  brokerId: z.coerce.number().int().positive("Broker is required"),
  supplierId: z.coerce.number().int().positive("Supplier is required"),
  swingId: z.coerce.number().int().positive("Swing is required"),
  passThroughId: z.coerce.number().int().positive("Pass Through is required"),
  billTypeId: z.coerce.number().int().positive("Bill Type is required"),
  productId: z.coerce.number().int().positive("Product is required"),
  meterIds: z.array(z.coerce.number().int().positive()).min(1, "Select at least one meter"),
  rate: z.coerce.number().finite().nonnegative("Rate must be zero or greater"),
  fee: z.coerce.number().finite().nonnegative("Fee must be zero or greater"),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  cFile: optionalText,
  contractFile: z.object({
    name: z.string().trim().min(1),
    contentType: z.string().trim().optional(),
    contentBase64: z.string().trim().min(1)
  }).optional(),
  notes: z.string().max(10000).refine((value) => value.replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, "").trim().length > 0, "Notes are required"),
  isActive: z.boolean().default(true),
  onDate: optionalDate
});

const tblContractCreateSchema = tblContractBaseSchema.superRefine((input, context) => {
  if (input.endDate < input.startDate) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["endDate"], message: "End date cannot be before start date" });
  }
  if (!input.contractFile && !input.cFile) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["contractFile"], message: "Contract file is required" });
  }
});

const tblContractUpdateSchema = tblContractBaseSchema.partial().superRefine((input, context) => {
  if (input.startDate && input.endDate && input.endDate < input.startDate) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["endDate"], message: "End date cannot be before start date" });
  }
});

async function saveContractNote(contractId: number, content: string | undefined, user: { id: string; orgId: string | null } | undefined) {
  if (content === undefined) return;
  const sanitizedContent = sanitizeCompanyNoteContent(content);
  const existing = await prisma.note.findFirst({
    where: { relatedType: "contract", relatedId: String(contractId) },
    orderBy: { updatedAt: "desc" },
    select: { id: true }
  });
  if (existing) {
    await prisma.note.update({ where: { id: existing.id }, data: { content: sanitizedContent } });
    return;
  }
  if (!sanitizedContent.replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, "").trim()) return;
  if (!user?.orgId) throw Object.assign(new Error("An organization is required to save contract notes"), { statusCode: 400 });
  await prisma.note.create({
    data: { orgId: user.orgId, userId: user.id, relatedType: "contract", relatedId: String(contractId), content: sanitizedContent }
  });
}

reportsRoutes.post("/contracts", authorize("company:create"), async (req, res, next) => {
  try {
    const input = tblContractCreateSchema.parse(req.body);
    const company = input.companyId ? await findTblCompanyById(input.companyId) : null;
    const contractFolderId = await resolveContractFolderId(company);
    if (input.contractFile && !contractFolderId) {
      return res.status(400).json({ error: "Company ContractFolderID or CompanyFolderID is required to upload contract files." });
    }

    const productName = await findTblProductNameById(input.productId);
    const companyName = typeof company?.companyName === "string" ? company.companyName : "";
    const renamedContractFile = input.contractFile && productName && companyName
      ? {
          ...input.contractFile,
          name: contractUploadFileName({
            originalName: input.contractFile.name,
            productName,
            companyName,
            startDate: input.startDate,
            endDate: input.endDate
          })
        }
      : input.contractFile;
    const uploadedFile = renamedContractFile && contractFolderId
      ? await uploadSharePointFile(contractFolderId, renamedContractFile)
      : null;
    const now = new Date();
    const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
      INSERT INTO dbo.tbl_Contract (
        [Broker],
        [Supplier],
        [Swing],
        [PassThrough],
        [BillType],
        [Rate-kWh/therms],
        [Fee-kWh/Dth],
        [Start Date],
        [End Date],
        [cFile],
        [isActive],
        [createdAt],
        [updatedAt],
        [OnDate]
      )
      OUTPUT INSERTED.[id] AS id
      VALUES (
        ${input.brokerId ?? null},
        ${input.supplierId ?? null},
        ${input.swingId ?? null},
        ${input.passThroughId ?? null},
        ${input.billTypeId ?? null},
        ${input.rate ?? null},
        ${input.fee ?? null},
        ${input.startDate ?? null},
        ${input.endDate ?? null},
        ${uploadedFile?.name ?? input.cFile ?? null},
        ${input.isActive},
        ${now},
        ${now},
        ${input.onDate ?? null}
      )
    `;

    const contractId = Number(rows[0]?.id);
    await upsertCompanyContractRelation(input.companyId, contractId, input.meterIds);
    await saveContractNote(contractId, input.notes, req.user);
    return res.status(201).json({ data: await findTblContractById(contractId) });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/contracts/bulk-status", authorize("company:update"), async (req, res, next) => {
  try {
    const input = z.object({
      ids: z.array(z.coerce.number().int().positive()).min(1).max(500)
        .transform((ids) => Array.from(new Set(ids))),
      isActive: z.boolean()
    }).parse(req.body);

    const updated = await prisma.$executeRaw(Prisma.sql`
      UPDATE dbo.tbl_Contract
      SET [isActive] = ${input.isActive}, [updatedAt] = ${new Date()}
      WHERE [id] IN (${Prisma.join(input.ids)})
    `);

    return res.json({ updated, isActive: input.isActive });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/contracts/:id", authorize("company:update"), async (req, res, next) => {
  try {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const current = await findTblContractById(id);
    if (!current) return res.status(404).json({ error: "Contract not found" });

    const input = tblContractUpdateSchema.parse(req.body);
    const companyId = input.companyId ?? Number(current.companyId ?? 0);
    const company = companyId ? await findTblCompanyById(companyId) : null;
    const contractFolderId = await resolveContractFolderId(company);
    if (input.contractFile && !contractFolderId) {
      return res.status(400).json({ error: "Company ContractFolderID or CompanyFolderID is required to upload contract files." });
    }

    const uploadedFile = input.contractFile && contractFolderId
      ? await uploadSharePointFile(contractFolderId, input.contractFile)
      : null;

    await prisma.$executeRaw`
      UPDATE dbo.tbl_Contract
      SET
        [Broker] = ${input.brokerId ?? current.brokerId ?? null},
        [Supplier] = ${input.supplierId ?? current.supplierId ?? null},
        [Swing] = ${input.swingId ?? current.swingId ?? null},
        [PassThrough] = ${input.passThroughId ?? current.passThroughId ?? null},
        [BillType] = ${input.billTypeId ?? current.billTypeId ?? null},
        [Rate-kWh/therms] = ${input.rate ?? current.rate ?? null},
        [Fee-kWh/Dth] = ${input.fee ?? current.fee ?? null},
        [Start Date] = ${input.startDate ?? current.startDate ?? null},
        [End Date] = ${input.endDate ?? current.endDate ?? null},
        [cFile] = ${uploadedFile?.name ?? input.cFile ?? current.cFile ?? null},
        [isActive] = ${input.isActive ?? current.isActive},
        [updatedAt] = ${new Date()},
        [OnDate] = ${input.onDate ?? current.onDate ?? null}
      WHERE [id] = ${id}
    `;

    await upsertCompanyContractRelation(input.companyId, id, input.meterIds);
    await saveContractNote(id, input.notes, req.user);
    return res.json({ data: await findTblContractById(id) });
  } catch (error) {
    return next(error);
  }
});

const tblCompanyCreateSchema = z.object({
  organizationId: z.preprocess(emptyStringToUndefined, z.coerce.number().int().positive().default(1)),
  companyName: z.string().trim().min(1, "Company name is required"),
  legalEntityName: z.string().trim().min(1, "Legal name is required"),
  mailingAddress: z.string().trim().min(1, "Mailing address is required"),
  city: z.string().trim().min(1, "City is required"),
  state: z.string().trim().min(1, "State is required"),
  country: optionalText,
  postalCode: z.string().trim().min(1, "ZIP is required"),
  email: z.preprocess(emptyStringToUndefined, z.string().trim().email("Enter a valid email address").optional()),
  phoneNumber: z.string().trim().min(1, "Phone number is required"),
  taxId: optionalText,
  url: optionalText,
  notes: z.string().max(1000).default(""),
  isActive: z.boolean().default(true)
});

const tblCompanyUpdateSchema = z.object({
  companyName: z.string().trim().min(1, "Company name is required"),
  legalEntityName: z.string().trim().min(1, "Legal name is required"),
  mailingAddress: z.string().trim().min(1, "Mailing address is required"),
  city: z.string().trim().min(1, "City is required"),
  state: z.string().trim().min(1, "State is required"),
  country: z.string().trim().optional(),
  postalCode: z.string().trim().min(1, "ZIP is required"),
  email: z.preprocess(emptyStringToUndefined, z.string().trim().email("Enter a valid email address").optional()),
  phoneNumber: z.string().trim().min(1, "Phone number is required"),
  taxId: z.string().trim().optional(),
  url: z.string().trim().optional(),
  notes: z.string().max(1000).optional(),
  isActive: z.boolean().optional()
});

function sanitizeCompanyNoteContent(content: string) {
  return content
    .replace(/<(script|style|iframe|object|embed|form)\b[^>]*>[\s\S]*?<\/\1>/gi, "")
    .replace(/<(script|style|iframe|object|embed|form)\b[^>]*\/?>/gi, "")
    .replace(/\s(on\w+|src|href)\s*=\s*(?:(["']).*?\2|[^\s>]+)/gi, "")
    .replace(/javascript:/gi, "");
}

async function saveCompanyNote(companyId: number, content: string | undefined, user: { id: string; orgId: string | null } | undefined) {
  if (content === undefined) return;
  const sanitizedContent = sanitizeCompanyNoteContent(content);
  const existingNotes = await prisma.$queryRaw<Array<{ id: string }>>`
    SELECT TOP (1) [id]
    FROM dbo.aae_notes
    WHERE [companyId] = ${companyId}
    ORDER BY [updatedAt] DESC
  `;
  const existing = existingNotes[0];
  if (existing) {
    await prisma.note.update({ where: { id: existing.id }, data: { content: sanitizedContent } });
    return;
  }
  if (!sanitizedContent.replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, "").trim()) return;
  if (!user?.orgId) throw Object.assign(new Error("An organization is required to save company notes"), { statusCode: 400 });
  const note = await prisma.note.create({
    data: { orgId: user.orgId, userId: user.id, relatedType: "company", relatedId: String(companyId), content: sanitizedContent }
  });
  await prisma.$executeRaw`UPDATE dbo.aae_notes SET [companyId] = ${companyId} WHERE [id] = ${note.id}`;
}

async function createTblCompany(input: z.infer<typeof tblCompanyCreateSchema>, user: { id: string; orgId: string | null } | undefined) {
  const sharePointFolder = await createCompanySharePointFolders(input.companyName);
  const inserted = await prisma.$queryRaw<Array<{ id: number }>>`
    INSERT INTO dbo.tblCompany (
      [organizationId], [Company Name], [Legal Entity Name], [Mailing Address],
      [city], [state], [country], [postalCode], [email], [Phone Number],
      [Tax ID], [URL], [CompanyFolderID], [ContractFolderID], [UtilityBillsFolderID],
      [isActive], [createdAt], [updatedAt]
    )
    OUTPUT INSERTED.[id] AS id
    VALUES (
      ${1}, ${input.companyName}, ${input.legalEntityName ?? null}, ${input.mailingAddress ?? null},
      ${input.city ?? null}, ${input.state ?? null}, ${input.country ?? null}, ${input.postalCode ?? null},
      ${input.email || null}, ${input.phoneNumber ?? null}, ${input.taxId ?? null}, ${input.url || null},
      ${sharePointFolder.companyFolderId ?? null}, ${sharePointFolder.contractFolderId ?? null},
      ${sharePointFolder.utilityBillsFolderId ?? null}, ${input.isActive}, ${new Date()}, ${new Date()}
    )
  `;
  const id = inserted[0]?.id;
  if (!id) throw new Error("Company was inserted but its ID was not returned");
  await saveCompanyNote(id, input.notes, user);
  return { data: await findTblCompanyById(id), sharePointFolder };
}

reportsRoutes.post("/tbl-companies", authorize("company:create"), async (req, res, next) => {
  try {
    const input = tblCompanyCreateSchema.parse(req.body);
    return res.status(201).json(await createTblCompany(input, req.user));
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.post("/tbl-companies/bulk", authorize("company:create"), async (req, res, next) => {
  try {
    const request = z.object({
      companies: z.array(z.unknown()).min(1).max(500),
      confirmDuplicates: z.boolean().default(false)
    }).parse(req.body);
    const existingRows = await prisma.$queryRaw<Array<{ companyName: string | null }>>`
      SELECT [Company Name] AS companyName FROM dbo.tblCompany
    `;
    const existingNames = new Set(existingRows.map((item) => item.companyName?.trim().toLowerCase()).filter(Boolean));
    const uploadedNames = new Set<string>();
    const duplicateNames = new Set<string>();

    for (const candidate of request.companies) {
      if (!candidate || typeof candidate !== "object" || !("companyName" in candidate)) continue;
      const companyName = String(candidate.companyName ?? "").trim();
      const normalizedName = companyName.toLowerCase();
      if (!normalizedName) continue;
      if (existingNames.has(normalizedName) || uploadedNames.has(normalizedName)) duplicateNames.add(companyName);
      uploadedNames.add(normalizedName);
    }

    if (duplicateNames.size && !request.confirmDuplicates) {
      return res.status(409).json({
        error: "One or more companies have the same name. Confirm to continue importing them.",
        requiresConfirmation: true,
        duplicates: Array.from(duplicateNames)
      });
    }
    const imported: Array<{ row: number; id: string | number | undefined; companyName: string }> = [];
    const errors: Array<{ row: number; companyName: string; error: string }> = [];

    for (const [index, candidate] of request.companies.entries()) {
      const row = index + 2;
      const parsed = tblCompanyCreateSchema.safeParse(candidate);
      if (!parsed.success) {
        const companyName = candidate && typeof candidate === "object" && "companyName" in candidate
          ? String(candidate.companyName ?? "")
          : "";
        errors.push({ row, companyName, error: parsed.error.issues[0]?.message ?? "Invalid company data" });
        continue;
      }

      try {
        const result = await createTblCompany(parsed.data, req.user);
        imported.push({ row, id: result.data?.id == null ? undefined : String(result.data.id), companyName: parsed.data.companyName });
      } catch (error) {
        errors.push({ row, companyName: parsed.data.companyName, error: error instanceof Error ? error.message : "Unable to create company" });
      }
    }

    return res.status(errors.length ? 207 : 201).json({
      total: request.companies.length,
      imported: imported.length,
      failed: errors.length,
      data: imported,
      errors
    });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/tbl-companies/bulk-status", authorize("company:update"), async (req, res, next) => {
  try {
    const input = z.object({
      ids: z.array(z.coerce.number().int().positive()).min(2).max(500)
        .transform((ids) => Array.from(new Set(ids))),
      isActive: z.boolean()
    }).parse(req.body);
    if (input.ids.length < 2) return res.status(400).json({ error: "Select at least two companies" });

    const updated = await prisma.$executeRaw(Prisma.sql`
      UPDATE dbo.tblCompany
      SET [isActive] = ${input.isActive}, [updatedAt] = ${new Date()}
      WHERE [id] IN (${Prisma.join(input.ids)})
    `);

    return res.json({ updated, isActive: input.isActive });
  } catch (error) {
    return next(error);
  }
});

reportsRoutes.patch("/tbl-companies/:id", authorize("company:update"), async (req, res, next) => {
  try {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const current = await findTblCompanyById(id);
    if (!current) return res.status(404).json({ error: "Company not found" });

    const statusOnly = z.object({ isActive: z.boolean() }).strict().safeParse(req.body);
    if (statusOnly.success) {
      await prisma.$executeRaw`
        UPDATE dbo.tblCompany
        SET [isActive] = ${statusOnly.data.isActive}, [updatedAt] = ${new Date()}
        WHERE [id] = ${id}
      `;
      return res.json({ data: await findTblCompanyById(id) });
    }

    const input = tblCompanyUpdateSchema.parse(req.body);
    await prisma.$executeRaw`
      UPDATE dbo.tblCompany
      SET
        [organizationId] = ${1},
        [Company Name] = ${input.companyName ?? current.companyName},
        [Legal Entity Name] = ${input.legalEntityName ?? current.legalEntityName ?? null},
        [Mailing Address] = ${input.mailingAddress ?? current.mailingAddress ?? null},
        [city] = ${input.city ?? current.city ?? null},
        [state] = ${input.state ?? current.state ?? null},
        [country] = ${input.country ?? current.country ?? null},
        [postalCode] = ${input.postalCode ?? current.postalCode ?? null},
        [email] = ${input.email || current.email || null},
        [Phone Number] = ${input.phoneNumber ?? current.phoneNumber ?? null},
        [Tax ID] = ${input.taxId ?? current.taxId ?? null},
        [URL] = ${input.url ?? current.url ?? null},
        [isActive] = ${input.isActive ?? current.isActive},
        [updatedAt] = ${new Date()}
      WHERE [id] = ${id}
    `;
    await saveCompanyNote(id, input.notes, req.user);

    return res.json({ data: await findTblCompanyById(id) });
  } catch (error) {
    return next(error);
  }
});

import { Router } from "express";
import { z } from "zod";
import { prisma } from "../db/prisma.js";
import { authorize } from "../middleware/authorize.js";

export const masterAccountNumberRoutes = Router();
masterAccountNumberRoutes.use(authorize("org:administer"));

const settingSchema = z.object({
  utilityId: z.number().int().positive(),
  accountNumber: z.boolean(),
  serviceRefPodId: z.boolean()
});

masterAccountNumberRoutes.get("/", async (_req, res, next) => {
  try {
    const data = await prisma.$queryRaw`
      SELECT m.[id], m.[UtilityId] AS utilityId, u.[Utility] AS utilityName,
        m.[AccountNumber] AS accountNumber, m.[ServiceRefPodId] AS serviceRefPodId
      FROM dbo.tblMasterAccountNumber m
      INNER JOIN dbo.tbl_Utility u ON u.[id] = m.[UtilityId]
      ORDER BY u.[Utility], m.[id]
    `;
    return res.json({ data });
  } catch (error) {
    return next(error);
  }
});

masterAccountNumberRoutes.put("/", async (req, res, next) => {
  try {
    const input = settingSchema.parse(req.body);
    const utilities = await prisma.$queryRaw<Array<{ id: number }>>`
      SELECT [id] FROM dbo.tbl_Utility WHERE [id] = ${input.utilityId}
    `;
    if (!utilities.length) return res.status(404).json({ error: "Utility not found." });
    await prisma.$executeRaw`
      MERGE dbo.tblMasterAccountNumber WITH (HOLDLOCK) AS target
      USING (SELECT ${input.utilityId} AS UtilityId) AS source
      ON target.[UtilityId] = source.UtilityId
      WHEN MATCHED THEN UPDATE SET
        [AccountNumber] = ${input.accountNumber}, [ServiceRefPodId] = ${input.serviceRefPodId}
      WHEN NOT MATCHED THEN INSERT ([UtilityId], [AccountNumber], [ServiceRefPodId])
        VALUES (${input.utilityId}, ${input.accountNumber}, ${input.serviceRefPodId});
    `;
    return res.json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

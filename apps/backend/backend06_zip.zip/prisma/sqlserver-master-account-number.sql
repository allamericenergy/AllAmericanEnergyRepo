IF OBJECT_ID('dbo.tblMasterAccountNumber', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.tblMasterAccountNumber (
    [id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [UtilityId] INT NOT NULL,
    [AccountNumber] BIT NOT NULL,
    [ServiceRefPodId] BIT NOT NULL,
    CONSTRAINT [UQ_tblMasterAccountNumber_UtilityId] UNIQUE ([UtilityId]),
    CONSTRAINT [FK_tblMasterAccountNumber_Utility] FOREIGN KEY ([UtilityId]) REFERENCES dbo.tbl_Utility ([id])
  );
END;
